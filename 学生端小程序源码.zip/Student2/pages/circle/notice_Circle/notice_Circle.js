// pages/circle/details_Circle/more_Comment/more_Comment.js
const app = getApp();
var util = require('../../../utils/util.js');
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    userInfo:'',
    title:['点赞','评论'],
    TabCur: 0,
  }, 
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    }) 
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-41,
        verifyCode:verifyCode
      });
     this.showLike();  //获取点赞列表
  },
  showLike(){
    wx.showLoading({
      title: '获取中',
    });
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/likeList',
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1){
          
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
   //评论输入
   comment_value(e){
    // console.log(e)
    this.setData({
      comment_value:e.detail.value
    })
  },
  //评论点击按钮
  on_comment(){
    var that = this,
    commentId = that.data.comment_data.commentId,
    backReceiver = that.data.comment_data.initiator,
    message = that.data.comment_data.message,
    dyId = that.data.comment_data.dyId,
    comment_value = that.data.comment_value;
    if(comment_value!=''){
      wx.request({
        url: 'https://graceful.top/exercise/dynamicMessage/writeBack',
        data:{
          dyId:dyId,
          message:comment_value,
          commentId:commentId,
          backReceiver:backReceiver
        },
        method:'post',
        header:{
        verifyCode:that.data.verifyCode,
        'content-type': 'application/x-www-form-urlencoded'
        },
        success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1&&data.data==true){
            //回复评论成功  本地数据增加
            var backReceiver = {};
            backReceiver.senderNickname = that.data.userInfo.nickName,
            backReceiver.senderAvatar = that.data.userInfo.avatarUrl,
            backReceiver.message =comment_value;
            let comment = that.data.comment_data;
            comment.writeBackList_length++;
            //遍历对应回复的评论数据 根据key
            comment.writeBackList.unshift(backReceiver);
            that.setData({
              comment_value:'',
              commentIfo:{},  //  重置回复信息内容
              comment_data:comment
            })
            wx.showToast({
              title: '发表成功',
              icon: 'none',
              duration: 2000
            })
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail(res){
        wx.hideLoading()
      }
      })
    }else{
      wx.showToast({
        title: '内容为空',
        icon: 'none',
        duration: 2000
      })
    }
    
   
  },
   //导航点击
   on_scroll(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
    })
  },
  swiper_change:function (e) {
    console.log(e)
    this.setData({
      TabCur: e.detail.current,
      
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})