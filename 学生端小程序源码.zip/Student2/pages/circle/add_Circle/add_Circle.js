// pages/my/notice/notice.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    imgList: [], 
    imgFile:[],   // 图片返回地址
    textareaAValue:'', //文本框值
    input_Value:'',   //标题内容
    circle_value:''   //动态数据  缓存用
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
    //判断缓存
    var circle_data = wx.getStorageSync('circle_value');
    console.log(circle_data)
    if(circle_data!=''){
      this.setData({
        textareaAValue : circle_data.textareaAValue,
        input_Value:circle_data.input_Value,
        imgList:circle_data.imgFile,
        imgFile:circle_data.imgFile
      })
    }

  },
  //发布按钮
  release(){
    var that = this,
        textareaAValue = this.data.textareaAValue,
        input_Value = this.data.input_Value,
        imgFile = this.data.imgFile,
        circle_value = {};
        if(textareaAValue.length==0){
          wx.showToast({
            title: '请输入内容',
            icon: 'none',
            duration: 2000
          })
        }else if(input_Value.length==0){
          wx.showToast({
            title: '请输入标题',
            icon: 'none',
            duration: 2000
          })
        }else{
          wx.showLoading({
            // title: '加载中',
          })
          circle_value.content = textareaAValue,
          circle_value.title = input_Value,
          circle_value.pictures = imgFile;
          circle_value = JSON.stringify(circle_value);
          console.log(circle_value)
          //接口
         
          wx.request({
            url: 'https://graceful.top/exercise/dynamicMessage/save',
            data:circle_value,
            method:'post',
            header:{
             verifyCode:that.data.verifyCode,
            //  'content-type': 'application/x-www-form-urlencoded'
            },
            success (res) {
             wx.hideLoading()
             var data = res.data;
             console.log(data)
             if(data.state==1&&data.data==true){
              wx.removeStorageSync('circle_value')
              wx.reLaunch({
                url: '/pages/circle/circle'
              })
             }else{
               wx.showToast({
                 title: '网络错误',
                 icon: 'none',
                 duration: 2000
               })
             }
           },
           fail(res){
             wx.hideLoading()
           }
          })
        }
  },
  //存草稿按钮
  draft(){
    var textareaAValue = this.data.textareaAValue,
        input_Value = this.data.input_Value,
        imgFile = this.data.imgFile,
         circle_value = {};
        if(textareaAValue.length==0){
          wx.showToast({
            title: '请输入内容',
            icon: 'none',
            duration: 2000
          })
        }else if(input_Value.length==0){
          wx.showToast({
            title: '请输入标题',
            icon: 'none',
            duration: 2000
          })
        }else{
          wx.showModal({
            // title: '召唤师',
            content: '是否保存草稿',
            cancelText: '不保存',
            confirmText: '保存',
            success: res => {
              if (res.confirm) {
                circle_value.textareaAValue = textareaAValue,
                circle_value.input_Value = input_Value,
                circle_value.imgFile = imgFile;
                wx.setStorageSync('circle_value', circle_value) 
                wx.showToast({
                 title: '保存成功',
                 icon: 'sucess',
                 duration: 2000,
                 success:function(){
                    wx.navigateBack({
                      delta: 1
                    })
                 }
               })
              }
            }
          })
           
        }
  },
  // 标题输入
  input_Value(e){
    this.setData({
      input_Value: e.detail.value
    })
  },
  //文本框输入
  textareaAInput(e) {
    this.setData({
      textareaAValue: e.detail.value
    })
  },
  //获取本地图片
  ViewImage(e) {
    
    if(this.data.img_Length<3){
      wx.previewImage({
        urls: this.data.imgList,
        current: e.currentTarget.dataset.url
      });
    }else{
      wx.showToast({
        title: '最多只能添加三张图片哦',
        icon: 'none',
        duration: 2000
      })
    }
  },
  //取消图片
  DelImg(e) {
    wx.showModal({
      // title: '召唤师',
      content: '删除这张照片？',
      cancelText: '再想想',
      confirmText: '再见',
      success: res => {
        if (res.confirm) {
          console.log(e.currentTarget.dataset.index)
          this.data.imgList.splice(e.currentTarget.dataset.index, 1);
          // this.data.imgFile.splice(e.currentTarget.dataset.index, 1);
          this.setData({
            imgList: this.data.imgList,
            imgFile:this.data.imgFile
          })
        }
      }
    })
  },
  //显示图片
  ChooseImage() {
    wx.chooseImage({
      count: 3, //默认9
      sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album','camera'], //从相册、相机选择
      success: (res) => {
        // console.log(123)
        if (this.data.imgList.length != 0) {
          this.setData({
            imgList: this.data.imgList.concat(res.tempFilePaths),
          })
          this.uploadFile_img()
        } else {
          this.setData({
            imgList: res.tempFilePaths,
          })
          this.uploadFile_img()
        }
        
      }
    });
  },
  uploadFile_img(){
    wx.showLoading({
      title: '加载中',
    })
    var that = this,
        imgList = that.data.imgList;
        if(that.data.imgList.length!=0){
          var file = [];
          for(let i=0;i<imgList.length;i++){
            wx.uploadFile({
              url: 'https://graceful.top/exercise/put-image',
              filePath: imgList[i],
              name: 'file',
              header:{
                "verifyCode":that.data.verifyCode
              },
              success (res){
                wx.hideLoading(); 
                file.push(JSON.parse(res.data).data);
                that.setData({
                  imgFile:file  
                })
              }
             })
            }
        }else{
          wx.uploadFile({
            url: 'https://graceful.top/exercise/put-image',
            filePath: imgList[0],
            name: 'file',
            header:{
              "verifyCode":that.data.verifyCode
            },
            success (res){
              wx.hideLoading(); 
              that.setData({
                imgFile:that.data.imgFile.concat(JSON.parse(res.data).data)
              })
            }
           })
          
        }
        
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})