// pages/my/notice/notice.js
const app = getApp();
var util = require('../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    userInfo:'',
    circle_data:[], //动态列表数据
    num:0,
    circle_List:['评论','点赞'],
    comment_value:'',   //评论输入值
    comment_List:[], //评论列表 
    modalName:'',    //回复评论模态框
    commentIfo:{},  //回复评论临时信息
    com_Placeholder:'写评论...',    //评论输入框提示
    auto_focus:false,   //控制键盘是否自动聚焦
    delelt_Com:false,   //判断是否能删除评论
    view_bot:0,
  },
  //页面返回上一层
  page_back:function (params) {
    wx.reLaunch({
      url: '/pages/circle/circle'
    })
  }, 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    }) 
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-50,
        verifyCode:verifyCode
      })
      //页面接收动态数据
      const eventChannel = this.getOpenerEventChannel()
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        if(data!=''){
          that.comment_List(data.circle_data.dyId)
          that.setData({
            auto_focus:data.isComment,
            circle_data:data.circle_data
          })
        }else{
          wx.showToast({
            title: '数据丢失',
            icon: 'none',
            duration: 2000
          })
        }
      })
  },
  //键盘高度发生变化
  bindkeychange(e){
    this.setData({
      view_bot:e.detail.height
    })
  },
  // input失去焦点
  bindblur(){
    this.setData({
      view_bot:0
    })
  },
  //查看更多评论
  more_comment(e){
    var that=this,
        key = e.target.dataset.key; //评论列表数组下标
    // console.log(e)
    wx.navigateTo({
      url: '/pages/circle/details_Circle/more_Comment/more_Comment',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { 
          comment_data: that.data.comment_List[key],
        })
      }
    })
  },
  //评论点击  选择回复、复制、删除
  clickComment(e){
    console.log(e)
    //评论id  评论内容  评论人
    var commentIfo = this.data.comment_List[e.target.dataset.key];  //评论数组下标
    commentIfo.key = e.target.dataset.key;
    var info = wx.getStorageSync('studentInfo');
    // console.log(info.studentId,commentIfo.initiator)
    if(info.studentId==commentIfo.initiator){
      this.setData({
        delelt_Com:true,
        commentIfo:commentIfo,
        modalName:'RadioModal'
      })
    }else{
      this.setData({
        delelt_Com:false,
        commentIfo:commentIfo,
        modalName:'RadioModal'
      })
    }
    
  },
  //删除自身评论
  delet_Com(){
    wx.showLoading({
      title: '删除中',
    })
    var that=this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/removeCom',
      data:{
        commentId:that.data.commentIfo.commentId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading() 
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
          //遍历对应回复的评论数据 根据key
          var comment = that.data.comment_List;
          // console.log(that.data.commentIfo.key)
          comment.splice(that.data.commentIfo.key,1)
          // console.log(comment)
          that.setData({
            comment_value:'', //  重置数据
            commentIfo:{},  
            comment_List:comment,
            modalName:'',
            delelt_Com:false
          })
          wx.showToast({
            title: '删除成功',
            icon: 'none',
            duration: 2000
          })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
  //回复评论按钮
  reply_Com(){
    this.setData({
      com_Placeholder:'回复'+this.data.commentIfo.nickname,
      modalName: null,
      auto_focus:true,
    })
  },
  //复制评论
  copy_Com(){
    var that = this;
    wx.setClipboardData({
      data: this.data.commentIfo.message,
      success: function (res) {
          wx.getClipboardData({
              success: function (res) {
                wx.showToast({
                  title: '复制成功',
                  icon: 'none',
                  duration: 2000
                })
                  that.setData({
                    modalName:null
                  })
              }
          })
      }
  })
  },
  //评论点击按钮
  on_comment(){
    var that =this,
        comment_value= that.data.comment_value,
        circleId = that.data.circle_data.dyId;
    if(this.data.com_Placeholder=='写评论...'){
      if(comment_value!=''){
        wx.request({
          url: 'https://graceful.top/exercise/dynamicMessage/comment',
          data:{
            dyId:circleId,
            message:comment_value
          },
          method:'post',
          header:{
           verifyCode:that.data.verifyCode,
           'content-type': 'application/x-www-form-urlencoded'
          },
          success (res) {
           wx.hideLoading()
           var data = res.data;
           console.log(data)
           if(data.state==1){
              //评论成功 本地数据渲染增加数据
              var comment_List = that.data.comment_List;
                comment_List.unshift(data.data);
            that.setData({
              comment_value:'',
              comment_List:comment_List
            })
            wx.showToast({
              title: '发表成功',
              icon: 'none',
              duration: 2000
            })
           }else{
             wx.showToast({
               title: '网络错误',
               icon: 'none',
               duration: 2000
             })
           }
         },
         fail(res){
           wx.hideLoading()
         }
        })
      }else{
        wx.showToast({
          title: '内容为空',
          icon: 'none',
          duration: 2000
        })
      }
    }else{
      var that = this,
          commentIfo = that.data.commentIfo;
      if(comment_value!=''){
          wx.request({
            url: 'https://graceful.top/exercise/dynamicMessage/writeBack',
            data:{
              dyId:circleId,
              message:comment_value,
              commentId:commentIfo.commentId,
              backReceiver:commentIfo.initiator
            },
            method:'post',
            header:{
             verifyCode:that.data.verifyCode,
             'content-type': 'application/x-www-form-urlencoded'
            },
            success (res) {
             wx.hideLoading() 
             var data = res.data;
             console.log(data)
             if(data.state==1){
                //遍历对应回复的评论数据 根据key
                var comment = that.data.comment_List;
                comment[commentIfo.key].writeBackList.unshift(data.data);
                that.setData({
                  comment_value:'',
                  commentIfo:{},  //  重置回复信息内容
                  comment_List:comment
                })
                wx.showToast({
                  title: '发表成功',
                  icon: 'none',
                  duration: 2000
                })
             }else{
               wx.showToast({
                 title: '网络错误',
                 icon: 'none',
                 duration: 2000
               })
             }
           },
           fail(res){
             wx.hideLoading()
           }
          })
      }else{
        wx.showToast({
          title: '内容为空',
          icon: 'none',
          duration: 2000
        })
      }
    }
   
  },
  //模态框隐藏
  hideModal(e) {
    this.setData({
      modalName: null,
    })
  },
  //评论输入
  comment_value(e){
    // console.log(e)
    this.setData({
      comment_value:e.detail.value
    })
  },
   //标题按钮
   on_List(e) {
    //  console.log(e)
     var index = e.target.dataset.index;
    if(index!=this.data.num){
      if(this.data.num==0){
        this.setData({
          num:1
        })
      }else{
        this.setData({
          num:0
        })
      }
    }
    
  },
  //获取评论列表
  comment_List(dyId){
    wx.showLoading({
      title: '加载中',
    })
    var that=this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/commentList',
      data:{
        dyId:dyId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
         for(let i=0;i<data.data.length;i++){
           data.data[i].time = that.formatDateTime(data.data[i].time)
         }
        //  console.log(data.data.writeBackList.length)
         that.setData({
          comment_List:data.data,
         })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
  //获取点赞列表
  showFabulous(){
    var that =this;
    
  },
  //数据解析
  analysis_data(data){
    var that=this,
    dynamicMessage = data.dynamicMessage,
    pageInfo = data.pageInfo;
    for(let i=0;i<dynamicMessage.length;i++){
      dynamicMessage[i].time = that.formatDateTime(dynamicMessage[i].time);   //时间转码
      //图片解析
      
      if(dynamicMessage[i].pictures.length==0){ //无图片
        dynamicMessage[i].isImg=0
      }else if(dynamicMessage[i].pictures.length==1){  //两张或以上
        dynamicMessage[i].isImg=1;
      }else if(dynamicMessage[i].pictures.length==2){  //两张或以上
        dynamicMessage[i].isImg=2;
      }if(dynamicMessage[i].pictures.length==3){  //两张或以上
        dynamicMessage[i].isImg=3;
      }
      // dynamicMessageList[i].isImg=0
    }
     that.setData({
       circle_data:dynamicMessage,
      //  totalPage:pageInfo.totalPage
     })
  },
  //时间转码  //月份日份
  formatDateTime:function (date) {
    // console.log(date)
           var time = new Date(Date.parse(date));
  //  console.log(time)
           time.setTime(time.setHours(time.getHours() + 8));
           var Y = time.getFullYear() + '-';
           var  M = this.addZero(time.getMonth()+1) + '月';
           var D = this.addZero(time.getDate()-1) + '日';
           var h = this.addZero(time.getHours()) + ':';
           var m = this.addZero(time.getMinutes()) ;
           var  s = this.addZero(time.getSeconds());
           return  M + D + h + m ;
    
  },
  // 数字补0操作
  addZero(num) {
      return num < 10 ? '0' + num : num;
  },
  //懒加载
  tolower(){
    // console.log(123)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //获取评论
    this.comment_List(this.data.circle_data.dyId)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})