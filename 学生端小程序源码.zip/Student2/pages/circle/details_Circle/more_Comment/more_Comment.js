// pages/circle/details_Circle/more_Comment/more_Comment.js
const app = getApp();
var util = require('../../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    userInfo:'',
    comment_data:'',    //列表数据
    comment_value:'',
    modalName:'',
    backCominfo:'',     //点击评论储存临时信息
    delelt_Com:false, //  控制只能删除自己的评论
    view_bot:0, //评论框位置
  }, 
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    }) 
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-50,
        verifyCode:verifyCode
      })
      //页面数据接收
      const eventChannel = this.getOpenerEventChannel()
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        if(data!=''){
          that.setData({
            comment_data:data.comment_data
          })
        }else{
          wx.showToast({
            title: '数据丢失',
            icon:'none'
          })
        }
      })
  },
   //键盘高度发生变化
   bindkeychange(e){
    this.setData({
      view_bot:e.detail.height
    })
  },
  // input失去焦点
  bindblur(){
    this.setData({
      view_bot:0
    })
  },
  //点击评论
  clickComment(e){
    console.log(e)
    var key = e.currentTarget.dataset.key,
        info = wx.getStorageSync('studentInfo'),
        studentId = info.studentId,
        comList = this.data.comment_data;
        comList.key = key;
    if(comList.writeBackList[key].backSender==studentId){    //判断是否删除评论
       this.setData({
        backCominfo:comList.writeBackList[key],
        modalName:'RadioModal',
        delelt_Com:true
      })
    }else{
      this.setData({
        backCominfo:comList.writeBackList[key],
        modalName:'RadioModal',
        delelt_Com:false
      })
    }
  },
  //删除评论
  delet_Com(){
    wx.showLoading({
      title: '删除中',
    })
    var that=this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/removeBack',
      data:{
        backId:that.data.backCominfo.backId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading() 
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
          //遍历对应回复的评论数据 根据key
          var comment = that.data.comment_data;
          // console.log(that.data.commentIfo.key)
          comment.writeBackList.splice(that.data.backCominfo.key,1)
          console.log(comment)
            that.setData({
              comment_value:'', //  重置数据
              backCominfo:{},  
              comment_List:comment,
              modalName:'',
              delelt_Com:false
            })
          wx.showToast({
            title: '删除成功',
            icon: 'none',
            duration: 2000
          })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
   //模态框隐藏
  hideModal(e) {
    this.setData({
      modalName: null,
    })
  },
   //评论输入
   comment_value(e){
    // console.log(e)
    this.setData({
      comment_value:e.detail.value
    })
  },
  //评论发表按钮
  on_comment(){
    var that = this,
    comment_data = that.data.comment_data,
    comment_value = that.data.comment_value;
    if(comment_value!=''){
      wx.request({
        url: 'https://graceful.top/exercise/dynamicMessage/writeBack',
        data:{
          dyId:comment_data.dyId,
          message:comment_value,
          commentId:comment_data.commentId,
          backReceiver:comment_data.initiator
        },
        method:'post',
        header:{
        verifyCode:that.data.verifyCode,
        'content-type': 'application/x-www-form-urlencoded'
        },
        success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1){
            //遍历对应回复的评论数据 根据key
            var comment = that.data.comment_data;
            comment.writeBackList.unshift(data.data);
            that.setData({
              comment_value:'',
              comment_data:comment
            })
            wx.showToast({
              title: '发表成功',
              icon: 'none',
              duration: 2000
            })
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail(res){
        wx.hideLoading()
      }
      })
    }else{
      wx.showToast({
        title: '内容为空',
        icon: 'none',
        duration: 2000
      })
    }
    
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})