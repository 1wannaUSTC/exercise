// pages/my/notice/notice.js
const app = getApp();
var sotk = null;
var socketOpen = false;
var wsbasePath = "ws://开发者服务器 wss 接口地址/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    startPage:1,  //起始页
    totalPage:'',    //总页数
    circle_data:[], //动态列表数据
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-160,
        verifyCode:verifyCode
      })
      that.show_circle(1,that.data.startPage,3)
     
  },
  //动态消息
  noticeCircle(){
    wx.navigateTo({
      url: '/pages/circle/notice_Circle/notice_Circle',
    })
  },
  //动态详情
 deltails_Circle(e){
     console.log(e)
    var that = this,  
        key = e.currentTarget.dataset.key;
    wx.navigateTo({
      url: '/pages/circle/details_Circle/details_Circle',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { 
          circle_data: that.data.circle_data[key],
          isComment:false
        })
      }
    })
 },
 //点赞按钮
 clike_like(e){
  var that= this,
      key = e.target.dataset.key,
      dyId = that.data.circle_data[key].dyId;
  if(that.data.circle_data[key].isLike){    //true已赞状态  取消赞接口
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/like',
      data:{
        dyId:dyId,
        isLike:false
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
         var circle_data = that.data.circle_data;
         circle_data[key].isLike=false;
         circle_data[key].like--;
         that.setData({
          circle_data:circle_data
         })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  }else{     //false未赞状态  请求赞接口
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/like',
      data:{
        dyId:dyId,
        isLike:true
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
         var circle_data = that.data.circle_data;
         circle_data[key].isLike=true;
         circle_data[key].like++;
         that.setData({
          circle_data:circle_data
         })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  }

  
 },
 //点击查看大图
 clike_img(e){
    console.log(e)
    var that = this,
        key = e.target.dataset.key,
        src = e.target.dataset.src;
    console.log(that.data.circle_data[key].pictures)
    //图片预览
    wx.previewImage({
      current: src, // 当前显示图片的http链接
      urls: that.data.circle_data[key].imgLis // 需要预览的图片http链接列表
    })
  },
  //点击评论
  clike_comment(e){
    var that = this,  
        key = e.target.dataset.key;
    wx.navigateTo({
      url: '/pages/circle/details_Circle/details_Circle',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { 
          circle_data: that.data.circle_data[key],
          isComment:true
        })
      }
    })
  },
  //点击发布
  addcircle(){ 
    wx.navigateTo({
      url: '/pages/circle/add_Circle/add_Circle',
    })
  },
  //获取动态列表
  show_circle(pattern,startPage,pageSize){
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/query?pattern=1',
      data:{
        pattern:pattern,
        startPage:startPage,
        pageSize:pageSize
      },
      method:'post', 
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
         that.analysis_data( data.data)
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
  //数据解析
  analysis_data(data){
    console.log(data)
    if(data!=null){
      var that=this,
        dynamicMessageList = data.dynamicMessageList,
        pageInfo = data.pageInfo;
        for(let i=0;i<dynamicMessageList.length;i++){
          dynamicMessageList[i].time = that.formatDateTime(dynamicMessageList[i].time);   //时间转码
          //图片解析
          if(dynamicMessageList[i].pictures.length==0){ //无图片
            dynamicMessageList[i].isImg=0
          }else if(dynamicMessageList[i].pictures.length==1){  //两张或以上
            dynamicMessageList[i].isImg=1;
            var img=[];
            img.push(dynamicMessageList[i].pictures[0].imagePath);
            dynamicMessageList[i].imgLis=img;
          }else if(dynamicMessageList[i].pictures.length==2){  //两张或以上
            dynamicMessageList[i].isImg=2;
            var img=[];
            img[0]=(dynamicMessageList[i].pictures[0].imagePath);
            img[1]=(dynamicMessageList[i].pictures[1].imagePath);
            dynamicMessageList[i].imgLis=img;
          }if(dynamicMessageList[i].pictures.length==3){  //两张或以上
            dynamicMessageList[i].isImg=3;
            var img=[];
            img[0]=(dynamicMessageList[i].pictures[0].imagePath);
            img[1]=(dynamicMessageList[i].pictures[1].imagePath);
            img[2]=(dynamicMessageList[i].pictures[2].imagePath);
            dynamicMessageList[i].imgLis=img;
          }
          // dynamicMessageList[i].isImg=0
        }
        if(that.data.startPage==1){
          that.setData({
            circle_data:dynamicMessageList,
            totalPage:pageInfo.totalPage
          })
        }else{
          var more_data=that.data.circle_data;
          that.setData({
            circle_data:more_data.concat(dynamicMessageList),
          })
        }
    }
  },
  //时间转码  //月份日份
  formatDateTime:function (date) {
    // console.log(date)
           var time = new Date(Date.parse(date));
  //  console.log(time)
           time.setTime(time.setHours(time.getHours() + 8));
           var Y = time.getFullYear() + '-';
           var  M = this.addZero(time.getMonth()+1) + '月';
           var D = this.addZero(time.getDate()-1) + '日';
           var h = this.addZero(time.getHours()) + ':';
           var m = this.addZero(time.getMinutes()) ;
           var  s = this.addZero(time.getSeconds());
           return  M + D + h + m ;
    
  },
  // 数字补0操作
  addZero(num) {
      return num < 10 ? '0' + num : num;
  },
  //懒加载
  tolower(){
    wx.showLoading({
      // title: '',
    })
    var that =this,
    startPage = that.data.startPage;
    if(startPage<=that.data.totalPage){
      startPage = startPage+1;
      // console.log(startPage)
      that.setData({
        startPage:startPage
      })
      this.show_circle(1,startPage,3)
    }else{
      wx.showToast({
        title: '已加载全部',
        icon:'none',
        duration: 2000
      })
    }
    
  },
  
  //开始webSocket
  webSocketStart(e){
    sotk = wx.connectSocket({
      url: '',
      header: { 'content-type': 'application/x-www-form-urlencoded' },
      method: "POST",
      success: res => {
        console.log('小程序连接成功：', res);
      },
      fail: err => {
        console.log('出现错误啦！！' + err);
        wx.showToast({
          title: '网络异常！',
        })
      }
    })
    this.webSokcketMethods();
  },
  //监听指令
  webSokcketMethods(e){
    let that = this;
    sotk.onOpen(res => {
      socketOpen = true;
      console.log('监听 WebSocket 连接打开事件。', res);
    })
    sotk.onClose(onClose => {
      console.log('监听 WebSocket 连接关闭事件。', onClose)
      socketOpen = false;
    })
    sotk.onError(onError => {
      console.log('监听 WebSocket 错误。错误信息', onError)
      socketOpen = false
    })

    sotk.onMessage(onMessage => {
      var data = JSON.parse(onMessage.data);
      console.log('监听WebSocket接受到服务器的消息事件。服务器返回的消息',data);
     
    })
   
  },
  //关闭连接
  closeWebsocket(str){
    if (socketOpen) {
      sotk.close(
        {
          code: "1000",
          reason: str,
          success: function () {
            console.log("成功关闭websocket连接");
          }
        }
      )
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // console.log(2)
    // this.show_circle(1,this.data.startPage,3)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that =this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/query?pattern=1',
      data:{
        pattern:1,
        startPage:1,
        pageSize:3
      },
      method:'post', 
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
        console.log(data)
       if(data.state==1){
         if(data.data.dynamicMessageList[0].dyId==that.data.circle_data[0].dyId){
            wx.showToast({
              title: '最新动态',
              icon:'none'
            })
         }else{
            wx.showToast({
              title: '更新成功',
              icon:'none'
            })
            var data =[];
            for(let i=0;i<3;i++){
              if(data.data.dynamicMessageList[i].dyId!=that.data.circle_data[i].dyId){
                data.push(data.data.dynamicMessageList[i])
              }
            }
            console.log(data)
            // Array.from(new Set(arr))
            that.analysis_data( data.data)
            wx.hideNavigationBarLoading() //完成停止加载
            wx.stopPullDownRefresh() //停止下拉刷新
         }
        
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    // console.log(12)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})