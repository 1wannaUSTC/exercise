// pages/my/notice/notice.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    userInfo:'',
    startPage:1,  //起始页
    totalPage:'',    //总页数
    circle_data:[], //动态列表数据
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    })
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-70,
        verifyCode:verifyCode
      })
      that.show_circle(that.data.startPage,3)
     
  },
  //删除动态
  deleteCircle(e){
    console.log(e)
    wx.showLoading({
      title: '删除中',
    })
    // console.log(e.target.dataset.key)
    var that = this,
        key = e.target.dataset.key,
        dyId = that.data.circle_data[key].dyId;
        
     wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/removeDy',
      data:{
        dyId:dyId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
         var temporary_data = that.data.circle_data;
         if(temporary_data.length==3){
            that.show_circle(1,3)
         }else{
          temporary_data.slice(key,1);
          // console.log(temporary_data.splice(key,1))
          that.setData({
            circle_data:temporary_data
          })
         }
          
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
    
  },
  //获取动态列表
  show_circle(startPage,pageSize){
    wx.showLoading({
      title: '获取中',
    })
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/queryMe',
      data:{
        startPage:startPage,
        pageSize:pageSize
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
         that.analysis_data( data.data)
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
  //数据解析
  analysis_data(data){
    var that=this,
    dynamicMessage = data.dynamicMessage,
    pageInfo = data.pageInfo;
    for(let i=0;i<dynamicMessage.length;i++){
      dynamicMessage[i].time = that.formatDateTime(dynamicMessage[i].time);   //时间转码
      //图片解析
      if(dynamicMessage[i].pictures.length==0){ //无图片
        dynamicMessage[i].isImg=0
      }else if(dynamicMessage[i].pictures.length==1){  //两张或以上
        dynamicMessage[i].isImg=1;
      }else if(dynamicMessage[i].pictures.length==2){  //两张或以上
        dynamicMessage[i].isImg=2;
      }if(dynamicMessage[i].pictures.length==3){  //两张或以上
        dynamicMessage[i].isImg=3;
      }
      // dynamicMessageList[i].isImg=0
    }
    var circle_data = that.data.circle_data;
        circle_data=circle_data.concat(dynamicMessage)
        console.log(circle_data)
     that.setData({
       circle_data:circle_data,
       totalPage:pageInfo.totalPage
     })
  },
  //时间转码  //月份日份
  formatDateTime:function (date) {
    // console.log(date)
           var time = new Date(Date.parse(date));
  //  console.log(time)
           time.setTime(time.setHours(time.getHours() + 8));
           var Y = time.getFullYear() + '-';
           var  M = this.addZero(time.getMonth()+1) + '月';
           var D = this.addZero(time.getDate()-1) + '日';
           var h = this.addZero(time.getHours()) + ':';
           var m = this.addZero(time.getMinutes()) ;
           var  s = this.addZero(time.getSeconds());
           return  M + D + h + m ;
    
  },
  // 数字补0操作
  addZero(num) {
      return num < 10 ? '0' + num : num;
  },
  //懒加载
  tolower(){
    // console.log(123)
    var that = this,
    startPage = that.data.startPage,
    totalPage = that.data.totalPage;
    if(startPage==totalPage){
      wx.showToast({
        title: '已加载全部',
        icon:'none',
        duration:'2000'
      })
    }else{
      wx.showLoading({
        title: '加载中',
      })
      startPage++;
      that.setData({
        startPage:startPage
      })
      that.show_circle(startPage,3)
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})