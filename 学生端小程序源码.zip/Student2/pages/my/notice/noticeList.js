// pages/my/notice/notice.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    notice_data:'',
    value:'',
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      
      const eventChannel = this.getOpenerEventChannel()
      eventChannel.emit('acceptDataFromOpenedPage', {data: 'test'});
      eventChannel.emit('someEvent', {data: 'test'});
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        var time = data.data.notification.time,
            value = '';
            console.log(time)
            time = parseInt(time.slice(0,2));
            
        if(time>0&&time<10){
          value='上午'
        }else if(time>10&&time<14){
          value='中午'
        }else{
          value='下午'
        }
        that.setData({
          value:value,
          notice_data:data.data
        })
        // console.log(that.data.notice_data)
        that.read_notice(data.data.notificationState.relationId)
      })
     
  },
  read_notice:function (relationId) {
    var that = this;
    wx.request({
      url: "https://graceful.top/exercise/notify/read",
      method: 'post',
      data:{
        relationId:relationId
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
      wx.hideLoading()
       var data = res.data.data;
       console.log(data)
        if(res.data.state==1){
        }
      },
      fail: function(){
        wx.hideLoading()
       wx.showToast({
         title: '网络错误',
         icon: 'none',
         duration: 1000
       })
      }
    })
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})