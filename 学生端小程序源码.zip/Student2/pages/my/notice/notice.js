// pages/my/notice/notice.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    notice_data:'',
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      that.show_notice();
  },
  // 点击消息
  on_notice:function (e) {
    var that = this,
      index = e.currentTarget.dataset.index,
      value = that.data.notice_data[index];
      wx.navigateTo({
        url: '/pages/my/notice/noticeList?id=1',
        events: {
          // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
          acceptDataFromOpenedPage: function(data) {
            // console.log(data)
          },
          someEvent: function(data) {
            // console.log(data)
          }
        },
        success: function(res) {
          // 通过eventChannel向被打开页面传送数据
          res.eventChannel.emit('acceptDataFromOpenerPage', { data:  value})
        }
      })
  },
  //获取消息
  show_notice:function () {
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/notify/query',
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data!=null){
         for(var i=0 ;i<data.data.length;i++){
            var time = data.data[i].notification.date
            data.data[i].notification.date = that.formatDateTime1(time);
            data.data[i].notification.time = that.formatDateTime2(time)
         }
         console.log(data.data)
          that.setData({
            notice_data:data.data
          })
       }else{
        that.setData({
          notice_data:''
        })
       }
     },
    })
  },
  // 删除
  on_delete:function(e) {
    console.log(e)
    var that=this,
    relationId = e.currentTarget.dataset.id;
    wx.request({
      url: 'https://graceful.top/exercise/notify/deleteNotify',
      method:'post',
      data:{
        relationId:relationId
      },
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
         that.show_notice();
       }else{
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 2000
        })
       }
     },
    })
  },
  //时间转码  //月份日份
   formatDateTime1:function (date) {
     console.log(date)
            var time = new Date(Date.parse(date));
    console.log(time)
            time.setTime(time.setHours(time.getHours() + 8));
            var Y = time.getFullYear() + '-';
            var  M = this.addZero(time.getMonth()+1) + '-';
            var D = this.addZero(time.getDate()-1) + ' ';
            var h = this.addZero(time.getHours()) + ':';
            var m = this.addZero(time.getMinutes()) + ':';
            var  s = this.addZero(time.getSeconds());
            return  M + D;
     
   },
  //  时间 时分秒
   formatDateTime2:function (date) {
            var time = new Date(Date.parse(date));
            time.setTime(time.setHours(time.getHours() + 8));
            var Y = time.getFullYear() + '-';
            var  M = this.addZero(time.getMonth() + 1) + '-';
            var D = this.addZero(time.getDate()) + ' ';
            var h = this.addZero(time.getHours()) + ':';
            var m = this.addZero(time.getMinutes()) ;
            var  s = this.addZero(time.getSeconds());
            return  h + m;
      // }
   },
    // 数字补0操作
  addZero(num) {
    return num < 10 ? '0' + num : num;
  },
  // ListTouch触摸开始
  ListTouchStart(e) {
    this.setData({
      ListTouchStart: e.touches[0].pageX
    })
  },
  // ListTouch计算方向
  ListTouchMove(e) {
    this.setData({
      ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
    })
  },
  // ListTouch计算滚动
  ListTouchEnd(e) {
    if (this.data.ListTouchDirection =='left'){
      this.setData({
        modalName: e.currentTarget.dataset.target
      })
    } else {
      this.setData({
        modalName: null
      })
    }
    this.setData({
      ListTouchDirection: null
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.show_notice();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})