// pages/my/notice/notice.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    follow_data:'',
    RadioModal:"",   //关注弹出层控制
    t_key:'',
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      that.show_follow();
  },
  // 点击老师
  on_notice:function (e) {
    var that = this,
      index = e.currentTarget.dataset.index;
      that.setData({
        RadioModal:'RadioModal',
        t_key:index
      })
  },
   //隐藏弹出层
  hideModal(e) {
    this.setData({
      RadioModal: null
    })
  },
  //获取消息
  show_follow:function () {
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/student-relation-teacher/relationTeacherList',
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
         
        //  console.log(data.data)
          that.setData({
            follow_data:data.data
          })
       }else{
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 2000
        })
       }
     },
    })
  },
  //取消关注
  on_teacher:function (e) {
    var that = this,
    teacherId = e.target.dataset.id;
    // console.log(teacherId)
    wx.request({
      url: 'https://graceful.top/exercise/student-relation-teacher/cancelRelation',
      method:'post',
      data:{
        teacherId:teacherId
      },
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
        //  console.log(data.data)
          if(data.data){
            wx.showToast({
              title: '取消成功',
              icon: 'success',
              duration: 2000
            })
            that.setData({
              RadioModal:''
            })
            that.show_follow();
          }else{
            wx.showToast({
              title: '取消失败',
              icon: 'none',
              duration: 2000
            })
          }
       }else{
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 2000
        })
       }
     },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})