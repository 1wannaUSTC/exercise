// pages/my/Collection/Collection.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    title:['习题收藏','试题收藏'],
    TabCur: 0,
    questionList:'',
    work_data:'',
    work_total:'',
    question_total:''
  },
   //页面返回上一层
   page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that =this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      that.questionList();
      that.workList();
  },
  //试题获取
  workList:function () {
    var that= this;
    wx.request({
      url: 'https://graceful.top/exercise/work/collectCount',
      method: 'post',
      header: {
        'Content-Type': 'application/x-www-form-urlencoded',
         verifyCode:that.data.verifyCode,
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
         for(var i=0;i<data.data.works.length;i++){
           var key = Math.floor(Math.random()*(10 - 1) + 1);
           data.data.works[i].work_img='http://148.70.115.4/exercise/static/slices/'+key+'.png'
         }
        //  wx.setStorageSync('work_data', data.data.works);
        //  wx.setStorageSync('totalPage', data.data.pageInfo.totalPage)
         that.setData({
           work_total:data.data.pageInfo.total,
           work_data:data.data.works
         })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    }) 
  },
   //点击套题
   on_work:function (e) {
    console.log(e)
    var workId = e.currentTarget.dataset.workid,
         teacherId = e.currentTarget.dataset.teacherid;
    wx.navigateTo({
      url: '/pages/questions/questionList?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', {
          workId:workId,
          teacherId:teacherId
        })
      }
    })
  },
  //习题获取
  questionList:function () {
    var that = this;
    wx.request({
      url: "https://graceful.top/exercise/question/collectCount",
      method: 'post',
      header: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
      wx.hideLoading()
       var data = res.data.data;
      //  console.log(data)
        if(res.data.state==1){
          // wx.setStorageSync('questionList', data.questionList)
            that.setData({
              question_total:data.pageInfo.total,
              questionList:data.QuestionBanks
            })
        }else{
           wx.showToast({
             title: '网络错误',
             icon: 'none',
             duration: 1000
           })
        }
      },
      fail: function(){
        wx.hideLoading()
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 1000
        })
      }
    })
  },
   //习题详情按钮
   on_question:function (e) {
    var index = e.currentTarget.dataset.index, //习题索引
      questionList = this.data.questionList,
      value='';
      // console.log(questionList)
      // console.log(index)
    for(var i=0;i<questionList.length;i++){
      if(index==i){
        value = questionList[i];
      }
    }
    wx.navigateTo({
      url: '/pages/questions/questionOne?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { data:value })
      }
    })
  },
  //导航点击
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      
    })
  },
  swiper_change:function (e) {
    // console.log(e)
    this.setData({
      TabCur: e.detail.current,
      
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    this.questionList();
    this.workList();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})