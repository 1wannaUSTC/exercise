// pages/my/my.js
import * as echarts from '../../ec-canvas/echarts';
const app = getApp();
var Chart=null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    mongolia_show: '',   //弹框show，none
    translateY: '',   //弹框样式
    userInfo:'',
    function_data:[{
      "iocn_Url":"/image/my_Icon/News.png",
      "function_Name":'我的消息',
      "function_Url":'/pages/my/notice/notice'   //功能路径
    },{
      "iocn_Url":"/image/circle1.png",
      "function_Name":'我的动态',
      "function_Url":'/pages/my/cicle/my_Cicle'   //功能路径
    },{
      "iocn_Url":"/image/my_Icon/Collection.png",
      "function_Name":'收藏习题',
      "function_Url":'/pages/my/Collection/Collection'   //功能路径
    },{
      "iocn_Url":"/image/my_Icon/Follow.png",
      "function_Name":'关注老师',
      "function_Url":'/pages/my/follow/teacher'   //功能路径
    },{
      "iocn_Url":"/image/my_Icon/switch.png",
      "function_Name":'更改课程',
      "function_Url":'choice_Subject'   //功能路径
    },
    // {
    //   "iocn_Url":"/image/my_Icon/Edition.png",
    //   "function_Name":'关于我们',
    //   "function_Url":""   //功能路径
    // }
  ],
    subjectList:'',   //json格式
    ec: {
      onInit: function (canvas, width, height) {
        chart = echarts.init(canvas, null, {
          width: width, 
          height: height
        });
        canvas.setChart(chart);
        return chart;
      },
      lazyLoad: true // 延迟加载
    },
    a:[12,8,23,14,5,8,16],
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
     //自定义头部方法
     var windowHeight = wx.getSystemInfoSync().windowHeight,
     verifyCode = wx.getStorageSync('verifyCode');
      that.setData({
        navH: app.globalData.navHeight,
        verifyCode:verifyCode,
        windowHeight:windowHeight-that.data.navH,
      })
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    })
    //图表数据
    // this.show_echarts();
    this.echartsComponnet = this.selectComponent('#mychart');
    //如果是第一次绘制
    if (!Chart) {
      this.init_echarts(); //初始化图表
    } else {
      this.setOption(Chart); //更新数据
    }
  },
  //图标数据获取
  show_echarts(){
    var that=this;
    wx.request({
      url: "https://graceful.top/exercise/exerciseLog/countWeek",
      method: 'post',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
        var data = res.data;
        console.log(data)
        if(data.state==1){
          that.setData({
            a:data.data
          })
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 1000
          })
        }
      },
      fail: function(){
       wx.showToast({
         title: '网络错误',
         icon: 'none',
         duration: 1000
       })
      }
    })

  },
   //初始化图表
   init_echarts: function () {
    this.echartsComponnet.init((canvas, width, height) => {
      // 初始化图表
      const Chart = echarts.init(canvas, null, {
        width: width,
        height:height
      });
      this.setOption(Chart)
      // 注意这里一定要返回 chart 实例，否则会影响事件处理等
      return Chart;
    });
  },
  setOption: function (Chart) {
    Chart.clear();  // 清除
    Chart.setOption(this.getOption());  //获取新数据
  },
  // 图表配置项
  getOption() {
    var self = this;
    var option = {
      height: 120,
      title: {//标题
        // show:false,
        top: 10,
        text: '七天答题数量统计',
        left: 10,
        textStyle: {
          fontSize: 17,
          color: '#00A0FA',
        },
        
      },
      renderAsImage: true, //支持渲染为图片模式
      // color: ["#FFC34F", "#FF6D60", "#44B2FB"],//图例图标颜色
      legend: {
        show: false,
        itemGap: 15,//每个图例间的间隔
        top: 100,
        x: 30,//水平安放位置,离容器左侧的距离  'left'
        z: 100,
        
        
      },
      grid: {//网格
        left: 20,
        top:60,
        containLabel: false,//grid 区域是否包含坐标轴的刻度标签
      },
      xAxis: {//横坐标
        type: 'category',
        splitLine: {//坐标轴在 grid 区域中的分隔线。
          show: true,
          lineStyle: {
            type: 'solid',
            color:"#E8E8E8"
          }
        },
        "axisLine": {       //轴线：隐藏
          "show": false
        },
        "axisTick": {       //刻度线：隐藏
            "show": false
        },
        boundaryGap: false,//1.true 数据点在2个刻度直接  2.fals 数据点在分割线上，即刻度值上
        data: ['One', 'Two', 'Thr', 'Fou', 'Fiv', 'Six', 'Sev'],
        // itemGap:15,
        axisLabel: {
          textStyle: {
            fontSize: 13,
            color: '#5D5D5D'
          }
        }
      },
      yAxis: {//纵坐标
        type: 'value',
        position:'left',
        splitNumber: 5,//坐标轴的分割段数
        splitLine: {//坐标轴在 grid 区域中的分隔线。
          show: false,
        },
        "axisLine": {       //轴线：隐藏
          "show": false
        },
        "axisTick": {       //刻度线：隐藏
            "show": false
        },
        axisLabel: {//坐标轴刻度标签
          "show": false,
        },
        min: 0,
        max: 30,
      },
      series: [{
        name: '',
        type: 'line',
        data: self.data.a,
        symbol: 'success',
        symbolSize: 5,//拐点的大小
        smooth: true,//折线平滑化
        itemStyle: {
          normal: {
            lineStyle: {
              width: 5,
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                {
                  offset: 0,
                  color: 'rgba(3, 118, 207, 1)'
                },{
                  offset: 1,
                  color: 'rgba(0, 216, 255, 1)'
                }])
            },
            borderColor: '#00A2FF',//拐点正常情况的颜色
             opacity: 1//正常情况下，不显示拐点
          },
          emphasis: {//选中情况下拐点的颜色
            borderWidth: 5,
            opacity: 1,
            backgroundColor:'#fff'
          }
        },
        areaStyle: {
          normal: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: 'rgba(70, 205, 142, 0.5)'
              },{
                  offset: 1,
                  color: 'rgba(225,225,225,0)'
              }])

          }
      },
      tooltip: {
        trigger: 'axis',//触发方式
        axisPointer:{
          type: 'shadow' , 
          axis :'x',
          lineStyle: {
            type: 'dashed',
            color: '#00C8C8'
          },
        },
      },
      label: {
        normal: {
          show: true,
        }
      },
      }],
    }
    return option;
  },
  //功能选择
  on_funbut:function (res) {
    var that = this;
    // console.log(res)
    var key = res.currentTarget.dataset.index;
    if(that.data.function_data[key].function_Url=="choice_Subject"){
      that.toggle()
    }else{
      wx.navigateTo({
        url: that.data.function_data[key].function_Url,
      })
      // console.log(function_Url)
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  //课程选择弹出层
  toggle() {
    var subjectList = wx.getStorageSync('subjectList')
    this.setData({
      subjectList:subjectList,
      modalName: 'ChooseModal',
    })
  },
  //课程选择点击事件
  ChooseCheckbox(e) {
    // console.log(e)
    let items = this.data.subjectList;
    let values = e.currentTarget.dataset.value;
    for (let i = 0, lenI = items.length; i < lenI; ++i) {
      if (items[i].subjectId == values) {
        items[i].checked = !items[i].checked;
        break
      }
    }
    this.setData({
      subjectList: items
    })
  },
  //取消操作
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },
   //确认课程
   onSubject:function (res) {
    var that = this,
      subjectList = that.data.subjectList,
      value = [];
    for(let i=0;i<subjectList.length;i++){
      if(subjectList[i].checked){
        value.push(subjectList[i].subjectId)
      }
    }
    // console.log(value)
    // console.log((value.join('')))
    if(value.length!=0){
      var info = wx.getStorageSync('studentInfo');
      var studentId = info.studentId;
      // var subjectId = that.data.subjectList[subjec_id].subjectId;
      // console.log(subjectId)
      //传给后端课程信息
      wx.request({
        url: 'https://graceful.top/exercise/student-subject/choose/'+studentId,
        data:{
         subjectsStr:value.join('')
        },
        header: {
          'Content-Type': 'application/json;charset=UTF-8',
          'verifyCode':that.data.verifyCode
         },
        success: function(res){
          var data = res.data;
          if(data.state==1){
            that.setData({    //取消弹框
              modalName: '',
             })
             wx.setStorageSync('isSubject', 'true');
             wx.showToast({
              title: '成功',
              icon: 'success',
              duration: 1000
            })
          }
        }
      })
    }else{
      wx.showToast({
        title: '至少选择一门课程',
        icon: 'none',
        duration: 1000
      })
    }
  },
  // 点击蒙层,隐藏picker
  mongolia(){
    var isSubject = wx.getStorageSync('isSubject');
    // console.log(isSubject)
    if(isSubject!=''){
      this.setData({    //取消弹框
        mongolia_show: '',
        translateY: ''
       })
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})