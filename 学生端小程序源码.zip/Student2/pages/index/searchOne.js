// pages/index/searchOne.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    questionList:'', 
    question_key:true,
  },
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  }, 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    // console.log(answer)
    //自定义头部方法
    this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight;
      that.setData({
        windowHeight:windowHeight-that.data.navH
      })
      const eventChannel = this.getOpenerEventChannel()
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        var searchKey = data.data;
        if(searchKey==''){
          wx.showToast({
            title: '搜索内容为空',
            icon: 'none',
            duration: 1000
          })
        }else{
          var verifyCode = wx.getStorageSync('verifyCode');
          wx.request({
            url: 'https://graceful.top/exercise//question/search2',
            header:{
              'Content-Type': 'application/x-www-form-urlencoded',
              'verifyCode':verifyCode
            },
            method:'post',
            data:{
              searchKey:searchKey,
              pageStart:1,
              pageSize:10
            },
            success:function(res) {
              wx.hideLoading()
              
              var data = res.data;
              console.log(data)
              if(data.state==1){
                if(data.data.pageInfo.total!=0){
                  that.setData({
                    question_key:false,
                    questionList:data.data.searchList
                  })
                }
              }else{
                wx.showToast({
                  title: '网络错误',
                  icon: 'none',
                  duration: 1000
                })
              }
            }
          })
             
        }
       
           
      })
  },
  //习题详情按钮
  on_question:function (e) {
    var index = e.currentTarget.dataset.index, //习题索引
    questionList = this.data.questionList,
    value='';
    // console.log(questionList)
    // console.log(index)
  for(var i=0;i<questionList.length;i++){
    if(index==i){
      value = questionList[i];
    }
  }
    wx.navigateTo({
      url: '/pages/questions/questionOne?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { data:value })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})