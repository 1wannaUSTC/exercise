// pages/index/question_comment/question_comment.js
const app = getApp();
var util = require('../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    comment_List:'',  //评论列表
    com_Placeholder:'写评论...',    
    commentIfo:'',
    comment_value:'',
    delet_com:false,
    questionId:'',
    auto_focus:false,   //键盘是否弹出
    view_bot:0,
  },
   //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    }) 
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-50,
        verifyCode:verifyCode
      })
    //页面接收数据
    const eventChannel = this.getOpenerEventChannel()
    eventChannel.on('acceptDataFromOpenerPage', function(data) {
      that.setData({
        questionId:data.questionId
      })
    })
    // 获取评论列表
    that.showComlist();
  },
  //键盘高度发生变化
  bindkeychange(e){
    this.setData({
      view_bot:e.detail.height
    })
  },
  // input失去焦点
  bindblur(){
    this.setData({
      view_bot:0
    })
  },
  //获取评论列表
  showComlist(){
    wx.showLoading({
      title: '加载中',
    })
    var _seft= this,
    questionId = _seft.data.questionId;
    // 请求评论
    wx.request({
      url: 'https://graceful.top/exercise/QuestionComment/queryCommentList',
      data:{
        questionId:questionId,
      },
      method:'POST',
      header:{
       verifyCode:_seft.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        var data = res.data;
        console.log("问题评论：",data)
        if(data.state==1){
          
          _seft.setData({
            comment_List:data.data
          })
          wx.hideLoading()
        }else{
          wx.hideLoading()
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
    })
  },
  //查看更多评论
  more_comment(e){
    var that=this,
        key = e.target.dataset.key; //评论列表数组下标
    // console.log(e)
    wx.navigateTo({
      url: '/pages/index/question_comment/more_comment/more_comment',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { 
          comment_data: that.data.comment_List[key],
        })
      }
    })
  },
   //评论输入
   comment_value(e){
    // console.log(e)
    this.setData({
      comment_value:e.detail.value
    })
  },
  //评论发表按钮
  on_comment(){
    wx.showLoading({
      title: '发表中',
    })
    var that =this,
        comment_value= that.data.comment_value,
        questionId = that.data.questionId;  //去评论列表的问题id
    if(this.data.com_Placeholder=='写评论...'){
      if(comment_value!=''){
        wx.request({
          url: 'https://graceful.top/exercise/QuestionComment/comment',
          data:{
            questionId:questionId,
            message:comment_value
          },
          method:'post',
          header:{
           verifyCode:that.data.verifyCode,
           'content-type': 'application/x-www-form-urlencoded'
          },
          success (res) {
           var data = res.data;
           console.log(data)
           if(data.state==1){
             var list = that.data.comment_List;
             list.unshift(data.data);
            //  console.log(data.data.backs)
            //  console.log(list)
              that.setData({
                com_Placeholder:'写评论...',
                comment_value:'',
                comment_List:list,
              })
              wx.hideLoading()
              wx.showToast({
                title: '发表成功',
                icon: 'none',
                duration: 2000
              })
           }else{
             wx.showToast({
               title: '网络错误',
               icon: 'none',
               duration: 2000
             })
           }
         },
         fail(res){
           wx.hideLoading()
         }
        })
      }else{
        wx.showToast({
          title: '内容为空',
          icon: 'none',
          duration: 2000
        })
      }
    }else{
      var commentIfo = that.data.commentIfo,
          comment_value = that.data.comment_value;
      if(comment_value!=''){
          wx.request({
            url: 'https://graceful.top/exercise/QuestionComment/writeBack',
            data:{
              commentId:commentIfo.commentId,
              message:comment_value,
              backReceiver:commentIfo.initiator //发表人id
            },
            method:'post',
            header:{
             verifyCode:that.data.verifyCode,
             'content-type': 'application/x-www-form-urlencoded'
            },
            success (res) {
             var data = res.data;
             console.log(data)
             if(data.state==1){
               var  list = that.data.comment_List;
               console.log(list[commentIfo.key].backs);
                    list[commentIfo.key].backs.unshift(data.data);
                    console.log(list[commentIfo.key].backs);
                that.setData({
                  comment_value:'',
                  com_Placeholder:'写评论...',
                  commentIfo:{},  //  重置回复信息内容
                  comment_List:list,
                })
                wx.hideLoading()
                wx.showToast({
                  title: '发表成功',
                  icon: 'none',
                  duration: 2000
                })
             }else{
               wx.showToast({
                 title: '网络错误',
                 icon: 'none',
                 duration: 2000
               })
             }
           },
           fail(res){
             wx.hideLoading()
           }
          })
      }else{
        wx.showToast({
          title: '内容为空',
          icon: 'none',
          duration: 2000
        })
      }
    }
   
  },
  //评论点击  选择回复、复制、删除
  clickComment(e){
      //评论id  评论内容  评论人
      var key = e.target.dataset.key, //评论数组下标\
          value = this.data.comment_List[key],
          info = wx.getStorageSync('studentInfo'),
          studentId = info.studentId;
          value.key = key;
      if(value.initiator==studentId){  //  判断评论是否为自身发起
        this.setData({
          delet_com:true,
          commentIfo:value,
          modalName:'RadioModal'
        })
      }else{
        this.setData({
          delet_com:false,
          commentIfo:value,
          modalName:'RadioModal'
        })
      }
      
  },
  //回复模态框隐藏
  hideModal(e) {
    this.setData({
      modalName: null,
    })
  },
  //回复评论按钮
  reply_Com(){
    this.setData({
      com_Placeholder:'回复'+this.data.commentIfo.nickName,
      modalName: null,
      auto_focus:true,
    })
  },
   //复制评论
   copy_Com(){
    var that = this;
    wx.setClipboardData({
      data: this.data.commentIfo.message,
      success: function (res) {
          wx.getClipboardData({
              success: function (res) {
                wx.showToast({
                  title: '复制成功',
                  icon: 'none',
                  duration: 2000
                })
                  that.setData({
                    modalName:null
                  })
              }
          })
      }
  })
  },
  //删除评论
  delet_Com(){
    wx.showLoading({
      title: '删除中',
    })
    var that=this;
    wx.request({
      url: 'https://graceful.top/exercise/dynamicMessage/removeCom',
      data:{
        commentId:that.data.commentIfo.commentId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       
       var data = res.data;
       console.log(data)
       if(data.state==1&&data.data==true){
          //遍历对应回复的评论数据 根据key
          var comment = that.data.comment_List;
          // console.log(that.data.commentIfo.key)
          comment.splice(that.data.commentIfo.key,1)
          console.log(comment)
            that.setData({
              comment_value:'', //  重置数据
              commentIfo:{},  
              comment_List:comment,
              modalName:'',
              delelt_Com:false
            })
            wx.hideLoading() 
          wx.showToast({
            title: '删除成功',
            icon: 'none',
            duration: 2000
          })
       }else{
         wx.showToast({
           title: '网络错误',
           icon: 'none',
           duration: 2000
         })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})