// pages/circle/details_Circle/more_Comment/more_Comment.js
const app = getApp();
var util = require('../../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    verifyCode:'',
    userInfo:'',
    comment_data:'',    //列表数据
    comment_value:'',
    view_bot:0, //评论框位置
  }, 
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //获取用户信息
    wx.getUserInfo({
      success: function (res) {
        that.setData({
          userInfo: res.userInfo
        }) 
      }
    }) 
     //自定义头部方法
     this.setData({
        navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
       verifyCode = wx.getStorageSync('verifyCode')
     that.setData({
        windowHeight:windowHeight-that.data.navH-50,
        verifyCode:verifyCode
      })
      //页面数据接收
      const eventChannel = this.getOpenerEventChannel()
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        if(data!=''){
          that.setData({
            comment_data:data.comment_data
          })
        }else{
          wx.showToast({
            title: '数据丢失',
            icon:'none'
          })
        }
      })
  },
   //键盘高度发生变化
   bindkeychange(e){
    this.setData({
      view_bot:e.detail.height
    })
  },
  // input失去焦点
  bindblur(){
    this.setData({
      view_bot:0
    })
  },
   //评论输入
   comment_value(e){
    // console.log(e)
    this.setData({
      comment_value:e.detail.value
    })
  },
  //评论点击按钮
  on_comment(){
    wx.showLoading({
      title: '发表中',
    })
    var that = this,
    comment_value = that.data.comment_value;
    if(comment_value!=''){
      wx.request({
        url: 'https://graceful.top/exercise/QuestionComment/writeBack',
        data:{
          commentId:that.data.comment_data.commentId,
          message:comment_value,
          backReceiver:that.data.comment_data.initiator //发表人id
        },
        method:'post',
        header:{
        verifyCode:that.data.verifyCode,
        'content-type': 'application/x-www-form-urlencoded'
        },
        success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1){
            var comList = that.data.comment_data;
                comList.backs.unshift(data.data)
            wx.showToast({
              title: '发表成功',
              icon: 'none',
              duration: 2000
            })
            that.setData({
              comment_data:comList
            })
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail(res){
        wx.hideLoading()
      }
      })
    }else{
      wx.showToast({
        title: '内容为空',
        icon: 'none',
        duration: 2000
      })
    }
    
   
  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})