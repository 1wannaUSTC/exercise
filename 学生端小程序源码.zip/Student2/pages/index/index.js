// pages/index/main.js
const app = getApp();
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    windowHeight:'',
    navH:'',
    verifyCode:'',  //身份码
    modalName: '',   //弹框show，none
    cardCur: 0,
    swiperList: [{
      id: 0,
      type: 'image',
      url: 'https://graceful.top/student_Img/Rotation/1.png'
      }, {
        id: 1, 
          type: 'image',
          url: 'https://graceful.top/student_Img/Rotation/2.png',
      }, {
        id: 2,
        type: 'image',
        url: 'https://graceful.top/student_Img/Rotation/3.png'
      }, {id: 3,
        type: 'image',
        url: 'https://graceful.top/student_Img/Rotation/4.png'
      },],
    text_type:"",
    difficulty: ['不限','简单', '一般', '困难'],
    difficulty_key:null,
    question_Type:['不限','单选','多选','简答'],
    type_key:null,
    score:['不限','从低到高','从高到低'],
    errorRate:['NO','ASC','DESC'],
    score_key:null,
    subject:'',     //数组格式
    subjectList:'',   //json格式
    subject_key:null,
    subjec_id:undefined,  //课程选择id
    complete_card:'',  //完成卡片数据
    questionList:[],  //习题列表数据
    sezrch_value:'',
    totalPage:0,    //总页数
    pageStart:1,    //当前页
    input_Class:1,  //input样式控制
  },

  /**
   * 生命周期函数--监听页面加载
   */
 
  onLoad: function (options) {
    var that=this;
    var verifyCode = wx.getStorageSync('verifyCode');
    that.setData({
      verifyCode:verifyCode
    })
    //判断登录状态
    var islogin = wx.getStorageSync('islogin');
    if(!islogin){
        wx.reLaunch({
         url: '/pages/login/login'
        })
    }else{  
      var isSubject = wx.getStorageSync('isSubject');
      //判断课程选择
      if(isSubject==''){  //判断课程选择
        that.toggle();
      }else{
        //获取完成卡片数据
      this.complete_card();
      //获取学科
      this.subject_value();
      // 获取习题列表
      this.questionList(that.data.pageStart,5)
      } 
    }
     //自定义头部方法
     var windowHeight = wx.getSystemInfoSync().windowHeight,
        statusBarHeight = wx.getSystemInfoSync().statusBarHeight,
        screenHeight = wx.getSystemInfoSync().screenHeight;
     var height = screenHeight - windowHeight;
     console.log(height)
    //  console.log(statusBarHeight)
      that.setData({
        navH: app.globalData.navHeight,
        windowHeight:windowHeight-app.globalData.navHeight
      })
      // 初始化towerSwiper 传已有的数组名即可 轮播图
      this.towerSwiper('swiperList');
      
  },
  //搜索框获取焦点
  bindfocus(e){
    console.log(e)
    this.setData({
      input_Class:2
    })
  },
  //搜索框失去焦点
  bindblur(){
    var that=this;
    this.setData({
      input_Class:3
    })
    setTimeout(function(){ 
      that.setData({
        input_Class:1
      })
     }, 1000);
  },
   //获取学科接口
   subject_value:function () {
    var that = this,
    data =wx.getStorageSync('subjectList');
      //获取所有学科
      wx.request({
        url: "https://graceful.top/exercise/subject/getAll",
        method: 'get',
        header: {
          'Content-Type': 'application/json',
          'verifyCode':that.data.verifyCode
        },
        success: function(res){
          var data = res.data;
          console.log(data)
          if(data.length>0){
              var a=[];
            data.unshift({
              subjectId:0,
              subjectName:"不限"
            })
            for(var i=0;i<data.length;i++){
              var subjectName = data[i].subjectName;
              a.push(subjectName)
            }
            that.setData({
              subject:a,
              subjectList:data
            })
          }else{
            wx.showToast({
              title: '网络错误',
              icon: 'none',
              duration: 1000
            })
          }
        },
        fail: function(){
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 1000
        })
        }
      })
         
  },
  
  //弹出选课
  toggle(e) {
    var that =this;
    //获取所有学科
    wx.request({
      url: "https://graceful.top/exercise/subject/getAll",
      method: 'get',
      header: {
        'Content-Type': 'application/json',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
        var data = res.data;
        // console.log(data)
        if(data.length>0){
          var a=[];
          for(var i=0;i<data.length;i++){
            var subjectName = res.data[i].subjectName;
            data[i].checked = false;
            a.push(subjectName)
          }
          // console.log(data)
          wx.setStorageSync('subjectList', data)
          that.setData({
            subject:a,
            subjectList:data
          })
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 1000
          })
        }
      },
      fail: function(){
       wx.showToast({
         title: '网络错误',
         icon: 'none',
         duration: 1000
       })
      }
    })
    this.setData({
      modalName: 'ChooseModal'
    })
  },
   //确认课程
   onSubject:function (res) {
    var that = this,
      subjectList = that.data.subjectList,
      value = [];
    for(let i=0;i<subjectList.length;i++){
      if(subjectList[i].checked){
        value.push(subjectList[i].subjectId)
      }
    }
    // console.log(value)
    // console.log((value.join('')))
    if(value.length!=0){
      var info = wx.getStorageSync('studentInfo');
      var studentId = info.studentId;
      // var subjectId = that.data.subjectList[subjec_id].subjectId;
      // console.log(subjectId)
      //传给后端课程信息
      wx.request({
        url: 'https://graceful.top/exercise/student-subject/choose/'+studentId,
        data:{
         subjectsStr:value.join('')
        },
        header: {
          'Content-Type': 'application/json;charset=UTF-8',
          'verifyCode':that.data.verifyCode
         },
        success: function(res){
          var data = res.data;
          if(data.state==1){
            that.setData({    //取消弹框
              modalName: '',
             })
             wx.setStorageSync('isSubject', 'true');
              //获取完成卡片数据
              that.complete_card();
              // 获取习题列表
              that.questionList(1,5)
             wx.showToast({
              title: '成功',
              icon: 'success',
              duration: 1000
            })
          }
        }
      })
    }else{
      wx.showToast({
        title: '至少选择一门课程',
        icon: 'none',
        duration: 1000
      })
    }
  },
  ChooseCheckbox(e) {
    // console.log(e)
    let items = this.data.subjectList;
    let values = e.currentTarget.dataset.value;
    for (let i = 0, lenI = items.length; i < lenI; ++i) {
      if (items[i].subjectId == values) {
        items[i].checked = !items[i].checked;
        break
      }
    }
    this.setData({
      subjectList: items
    })
  },
  //搜索按钮事件
  on_search:function (e) {
    console.log(e)
    var value = e.detail.value,
        that = this;
    if(value==''){
      wx.showToast({
        title: '请输入内容！',
        icon: 'none',
        duration: 1000
      })
    }else{
      wx.navigateTo({
        url: '/pages/index/searchOne?id=1',
        events: {
          // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
          acceptDataFromOpenedPage: function(data) {
            // console.log(data)
          },
          someEvent: function(data) {
            // console.log(data)
          }
        },
        success: function(res) {
          // 通过eventChannel向被打开页面传送数据
          res.eventChannel.emit('acceptDataFromOpenerPage', { data:value })
          that.setData({
            sezrch_value:''
          })
        }
      })
    }
  },
  //习题详情按钮
  on_question:function (e) {
    var index = e.currentTarget.dataset.index, //习题索引
      questionList = this.data.questionList,
      value='';
      // console.log(questionList)
      // console.log(index)
    for(var i=0;i<questionList.length;i++){
      if(index==i){
        value = questionList[i];
      }
    }
    wx.navigateTo({
      url: '/pages/questions/questionOne?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { data:value })
      }
    })
  },
  //刷新习题列表按钮
  on_Refresh:function (res) {
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    this.setData({
      difficulty_key:null,
      type_key:null,
      subject_key:null,
      score_key:null
    })
    wx.request({
      url: "https://graceful.top/exercise/question/subPage",
      method: 'get',
      data:{
        pageStart:1,
        pageSize:5,
        isPublic:1
      },
      header: {
        'Content-Type': 'application/json',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
      wx.hideLoading()
       var data = res.data.data;
       console.log(data)
        if(res.data.state==1){
          // wx.setStorageSync('questionList', data.questionList)
          if(data.questionList[0].questionId==that.data.questionList[0].questionId){
            wx.showToast({
              title: '已是最新习题',
              icon: 'none',
              duration: 1000
            })
          }else{
            that.setData({
              pageStart:data.pageMessage.pageStart,
              totalPage:data.pageMessage.totalPage,
              questionList:data.questionList
            })
          } 
        }else{
           wx.showToast({
             title: '网络错误',
             icon: 'none',
             duration: 1000
           })
        }
      },
      fail: function(){
        wx.hideLoading()
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 1000
        })
      }
    }) 
  },
  // 获取习题列表
  questionList:function (pageStart,pageSize) {  //页码、题数
    var that = this;
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: "https://graceful.top/exercise/question/subPage",
      method: 'get',
      data:{
        pageStart:pageStart,
        pageSize:pageSize,
        isPublic:1
      },
      header: {
        'Content-Type': 'application/json',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
      wx.hideLoading()
       var data = res.data.data;
      //  console.log(data)
        if(res.data.state==1){
          // wx.setStorageSync('questionList', data.questionList)
          var questionList = data.questionList;
          for(let i=0;i<data.questionList.length;i++){
            questionList[i].errorRate =  questionList[i].error/(questionList[i].correct+questionList[i].error)
            // console.log(questionList[i].errorRate)
            if(isNaN(questionList[i].errorRate)){
              questionList[i].errorRate = 0;
              // console.log(questionList[i].errorRate)
            }else{
              questionList[i].errorRate = questionList[i].errorRate.toFixed(2)
            }
          }
          // console.log(questionList)
          var ques_data = that.data.questionList;
              ques_data = ques_data.concat(data.questionList);

          if(pageStart==1){
            
            that.setData({
              pageStart:data.pageMessage.pageStart,
              totalPage:data.pageMessage.totalPage,
              questionList:questionList
            })
          }else{
            that.setData({
              pageStart:data.pageMessage.pageStart,
              totalPage:data.pageMessage.totalPage,
              questionList:ques_data
            })
          }
            
        }else{
           wx.showToast({
             title: '网络错误',
             icon: 'none',
             duration: 1000
           })
        }
      },
      fail: function(){
        wx.hideLoading()
       wx.showToast({
         title: '网络错误',
         icon: 'none',
         duration: 1000
       })
      }
    })
  },
  //获取完成卡片数据
  complete_card:function (res) {
     
    //  console.log(verifyCode)
    var that = this;
    wx.request({
             url: "https://graceful.top/exercise/exerciseInfo/query",
             method: 'post',
             header: {
               'Content-Type': 'application/x-www-form-urlencoded',
               'verifyCode':that.data.verifyCode
              },
             success: function(res){
              //  console.log(res)
              var data = res.data.data;
               if(res.data.state==1){
                  data.complete = data.correct+data.error;
                  // console.log(data)
                  that.setData({
                    complete_card:data
                  })
               }else{
                  wx.showToast({
                    title: '网络错误',
                    icon: 'none',
                    duration: 1000
                  })
               }
             },
             fail: function(){
              wx.showToast({
                title: '网络错误',
                icon: 'none',
                duration: 1000
              })
             }
         })
  },
  // 点击蒙层,隐藏picker
  mongolia(){
    wx.showToast({
      title: '请选择课程哦',
      icon: 'none',
      duration: 1000
    })
    var isSubject = wx.getStorageSync('isSubject');
    // console.log(isSubject)
    if(isSubject!=''){
      this.setData({    //取消弹框
        mongolia_show: '',
        translateY: ''
       })
    }
  },
  //难度选择
  difficulty_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    if(e.detail.value=='0'){
      this.setData({
        difficulty_key:null
      })
      this.questionList(1,5)
    }else{
      this.setData({
        difficulty_key:e.detail.value
      })
      this.screen_request(1,6,this.data.difficulty[e.detail.value])
    }
  },
  //题型选择
  type_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    if(e.detail.value=='0'){
      this.setData({
        type_key:null
      })
      this.questionList(1,5)
    }else{
      this.setData({
        type_key:e.detail.value
      })
      this.screen_request(1,5,this.data.question_Type[e.detail.value].trim())
    }
  },
  //分值选择
  score_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    if(e.detail.value=='0'){
      this.setData({
        score_key:null
      })
      this.questionList(1,5)
    }else{
      this.setData({
        score_key:e.detail.value
      })
      this.screen_request(1,6,this.data.errorRate[e.detail.value])
    }
  },
  //学科选择
  subject_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    if(e.detail.value=='0'){
      this.setData({
        subject_key:null
      })
      this.questionList(1,5)
    }else{
      this.setData({
        subject_key:e.detail.value
      })
      this.screen_request(1,5,this.data.subjectList[e.detail.value].subjectId)
    }
  },
  //筛选接口请求
  screen_request:function (pageStart,pageSize,content) {
    var that = this; 
    var that = this;
    let difficulty='',type='',errorRate='',subjectId='';
    for(var i=0 ;i<that.data.subject.length;i++){    //循环控制在3，选项数量目前只为3
      if(content==that.data.difficulty[i]){
        difficulty = content;
        break;
      }else if(content==that.data.question_Type[i]){
        type = content;
        break;
      }else if(content==that.data.errorRate[i]){
        errorRate = content;
        break;
      }else if(content==that.data.subjectList[i].subjectId){
        subjectId = content;
        break;
      }
    }
    // console.log(content)
    // console.log(difficulty)
    // console.log( typeof type);
    // console.log(errorRate)
    console.log(subjectId)
    
    wx.request({
      url: "https://graceful.top/exercise/question/screen",
      method: 'post',
      data:{
        pageStart:pageStart,
        pageSize:pageSize,
        isPublic:1,
        subjectId:subjectId,
        type:type.trim(),
        difficulty:difficulty.trim(),
        errorRate:errorRate.trim()
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        'verifyCode':that.data.verifyCode
       },
      success: function(res){
      wx.hideLoading()
       var data = res.data.data;
      //  console.log(data)
        if(res.data.state==1){
          // wx.setStorageSync('questionList', data.questionList)
          var questionList = data.questionList;
          for(let i=0;i<data.questionList.length;i++){
            questionList[i].errorRate =  questionList[i].error/(questionList[i].correct+questionList[i].error)
            // console.log(questionList[i].errorRate)
            if(isNaN(questionList[i].errorRate)){
              questionList[i].errorRate = 0;
              // console.log(questionList[i].errorRate)
            }else{
              questionList[i].errorRate = questionList[i].errorRate.toFixed(2)
            }
          }
          console.log(questionList)
          var ques_data = that.data.questionList;
            ques_data = ques_data.concat(data.questionList);
          if(pageStart==1){
            that.setData({
              pageStart:data.pageMessage.pageStart,
              totalPage:data.pageMessage.totalPage,
              questionList:questionList
            })
          }else{
            that.setData({
              pageStart:data.pageMessage.pageStart,
              totalPage:data.pageMessage.totalPage,
              questionList:ques_data
            })
          }
        }else{
           wx.showToast({
             title: '网络错误',
             icon: 'none',
             duration: 1000
           })
        }
      },
      fail: function(){
        wx.hideLoading()
       wx.showToast({
         title: '网络错误',
         icon: 'none',
         duration: 1000
       })
      }
    })
  },
  //懒加载
  tolower(){
    var pageStart = this.data.pageStart+1,
          totalPage = this.data.totalPage,
          work_data = wx.getStorageSync('work_data');
            if(work_data!=''&&totalPage!=0){    //判断是否有习题可加载
              wx.showLoading({
                title: '加载中',
              })
              if(totalPage>=pageStart){
                if(this.data.difficulty_key!=null){
                  this.screen_request(pageStart,5,this.data.difficulty[this.data.difficulty_key])
                }else if(this.data.subject_key!=null){
                  this.screen_request(pageStart,5,this.data.subjectList[this.data.subject_key].subjectId)
                }else if(this.data.score_key!=null){
                  this.screen_request(pageStart,5,this.data.score[this.data.score_key])
                }else if(this.data.type_key!=null){
                  this.screen_request(pageStart,5,this.data.question_Type[this.data.type_key])
                }else{
                  this.questionList(pageStart,5)
                }
              }else{
                wx.hideLoading()
                wx.showToast({
                  title: '已加载全部',
                  icon: 'none',
                  duration: 2000
                })
              }
            }
  },
  // cardSwiper
  cardSwiper(e) { 
    this.setData({
      cardCur: e.detail.current
    })
  },
  // towerSwiper
  // 初始化towerSwiper
  towerSwiper(name) {
    let list = this.data[name];
    for (let i = 0; i < list.length; i++) {
      list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
      list[i].mLeft = i - parseInt(list.length / 2)
    }
    // console.log(list)
    this.setData({
      swiperList: list
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})