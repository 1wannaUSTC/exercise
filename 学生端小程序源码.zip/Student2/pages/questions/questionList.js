// pages/questions/questionList.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    RadioModal:"",   //关注弹出层控制
    card:1,    //卡片内容  1答题卡 2关注
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    isFollow:'',    //是否关注
    hours: '0' + 0,   // 时
    minute: '0' + 0,   // 分
    second: '0' + 0,    // 秒
    work_data:'',   //习题数据
    question_leng:'',   //习题长度
    workIsCollect:'',   //收藏状态 
    subject_type:0,   //题型判断
    swiper_index:0,
    questionId:'',
    teacher_info:'',    //老师信息

  },
   //页面返回上一层
   page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
     //自定义头部方法
     this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
         verifyCode = wx.getStorageSync('verifyCode');
      that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      const eventChannel = this.getOpenerEventChannel()
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        if(data!=''){
          var tr = that.show_wrok(data).then(function(value){ // value来接收resolve传递过来的参数（返回值）
            // console.log(value)    // 根据返回值处理业务逻辑
            that.setData({
              isFollow:value.teacherIsFollow,
              workIsCollect:value.workIsCollect
            })
            that.options_key(value);
           
        }, function(value) {      //value来接收reject传递过来的参数（返回值）
          console.log(value); });
        }
      })
      // 调用计时器
      this.setInterval();
  },
  //交卷
  on_subimt:function (e) {
    wx.showLoading({
      title: 'AI批阅中...',
    })
    var that= this,
    questionList = that.data.work_data.questions,
    time = that.data.hours+":"+that.data.minute+':'+that.data.second,
    key = false,
    submit={
      workId:that.data.work_data.workId,
      answer:{}
    };
    for(var i=0 ;i<questionList.length;i++){
      console.log(questionList[i].final_answer)
      if(questionList[i].final_answer!=''){
        submit.answer[questionList[i].questionId]=questionList[i].final_answer;
        key = true;
      }else{
        key = false,
        wx.showToast({
          title: '请将习题答完',
          icon: 'none',
          duration: 2000
        })
        break;
      }
      // console.log(submit)
    }
    // console.log(key)
    if(key){
      wx.request({
        url: 'https://graceful.top/exercise/work/read',
        data:JSON.stringify(submit),
        method:'POST',
        header:{
         verifyCode:that.data.verifyCode,
         'content-type': 'application/json;charset=UTF-8'
        },
        success (res) {
          wx.hideLoading()
         var data = res.data;
        //  console.log(data)
         data.data.time =time;
         if(data.state==1){
          wx.navigateTo({
            url: '/pages/questions/result?id=1',    //跳转至成绩页面
            events: {
              // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
              acceptDataFromOpenedPage: function(data) {
                console.log(data)
              },
              someEvent: function(data) {
                console.log(data)
              }
            },
            success: function(res) {
              // 通过eventChannel向被打开页面传送数据
              res.eventChannel.emit('acceptDataFromOpenerPage', { data: data.data })
            }
          })
         }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
         }
       },
      })
    }
  },
  //swiper.current改变事件
  swiper_change:function (e) {
    var that = this;
    that.setData({
      swiper_index:e.detail.current
    })
  },
  //隐藏弹出层
  hideModal(e) {
    this.setData({
      RadioModal: null
    })
  },
  //答题卡图标点击事件
  card_iocn:function (e) {
    this.setData({
      RadioModal:'',
      swiper_index:e.target.dataset.index
    })
  },
  //点击答题卡
  on_Answer:function (e) {
    var that = this;
    that.setData({
      RadioModal:'RadioModal',
      card:1
    })
  },
  //点击关注  弹出教师信息框
  on_follow_card:function (e) {
    wx.showLoading({
      title: '加载中',
    })
    console.log(e)
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/teacher/info',
      data:{
        teacherId:that.data.work_data.teacherId
      },
      method:'get',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/json'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
          that.setData({
            teacher_info:data.data,
            RadioModal:'RadioModal',
            card:2
          })
       }else{
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 2000
        })
       }
     },
    })
  },
  //关注老师请求
  on_teacher:function () {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/student-relation-teacher/relation',
      data:{
        teacherId:that.data.work_data.teacherId
      },
      method:'post',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
        wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.state==1){
          that.setData({
            RadioModal:'',
            isFollow:true
          })
          wx.showToast({
            title: '关注成功',
            icon: 'success',
            duration: 2000
          })
       }else{
        wx.showToast({
          title: '网络错误',
          icon: 'none',
          duration: 2000
        })
       }
     },
    })
  },
   //多选点击事件
   on_option:function (e) {
    var that = this,
    question_index = that.data.swiper_index,
    work_data = that.data.work_data,
    questionList = work_data.questions[question_index],
    index = e.target.dataset.j,
    options = questionList.optionList;
    if(options[index].isOk==1){
      options[index].isOk=0;
    }else{
      options[index].isOk=1
    }
    questionList.optionList = options;
    work_data.questions[question_index] = questionList;
    that.setData({
      work_data:work_data
    })
    // console.log(options)
  },
  //简答触发事件
  textareaAInput:function (e) {
    var that = this,
        question_index = that.data.swiper_index,
        work_data = that.data.work_data,
        questionList = work_data.questions[question_index],
        value = e.detail.value;
        questionList.final_answer = value; 
  },
  // 答案确认事件
  on_answer:function (e) {
    var that = this,
        question_index = that.data.swiper_index,
        work_data = that.data.work_data,
        questionList = work_data.questions[question_index],
        subject_type = questionList.type,
        index = e.target.dataset.j;
        if(subject_type=='单选'){
          var options = questionList.optionList;
          for(var i=0;i<options.length;i++){
            if(index==i){
              questionList.final_answer = options[index].option.slice(0,1);
              break;
            }
          }
          if(options[index].isOk==1){
            options[index].isOk=0;
            questionList.final_answer = '';
          }else{
            options[index].isOk=1
          }
          // console.log(options[index].isOk,index)
          for(var j=0;j<4;j++){
              if(index!=j){
                options[j].isOk=0;
                // console.log(options[index].isOk)
              }
          };
          console.log(questionList.final_answer)
          questionList.optionList = options;
          work_data.questions[question_index] = questionList;
          that.setData({
            work_data:work_data
          })
        }else if(subject_type=='多选'){
          var options = questionList.optionList,
              value = '';
          for(var i=0;i<4;i++){
            if(options[i].isOk==1){
              value+=options[i].option.slice(0,1)+',';
            }
          }
          value=value.substr(0,value.length-1)
          questionList.final_answer = value;
          work_data.questions[question_index] = questionList;
          that.setData({
            work_data:work_data
          })
          console.log(questionList.final_answer)
        }
        // console.log(question_index)
        if(question_index==that.data.question_leng-1){
          wx.showLoading({
            title: '加载中',
          })
          that.on_subimt();
        }else{
          that.setData({
            swiper_index:question_index+1
          })
        }
        
  },
  //点击收藏
  on_Collection:function (e) {
    console.log(e)
    var that =this,
        workId = e.target.dataset.index,
        workIsCollect=that.data.workIsCollect;
    if(!workIsCollect){    //收藏接口
      wx.showModal({
        title: '提示',
        content: '收藏套题',
        success (res) {
          if (res.confirm) {
            wx.request({
              url: 'https://graceful.top/exercise/work/collect',
              data:{
                workId:workId,
                cancelOrCollect:!workIsCollect
              },
              method:'POST',
              header:{
               verifyCode:that.data.verifyCode,
               'content-type': 'application/x-www-form-urlencoded'
              },
              success (res) {
               var data = res.data;
              //  console.log(data)
               if(data.state==1){
                  that.setData({
                    workIsCollect:data.data
                  })
                  wx.showToast({
                    title: '收藏成功',
                    icon: 'success',
                    duration: 2000
                  })
               }
             },
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '取消收藏',
        success (res) {
          if (res.confirm) {
            wx.request({
              url: 'https://graceful.top/exercise/work/collect',
              data:{
                workId:workId,
                cancelOrCollect:!workIsCollect
              },
              method:'POST',
              header:{
               verifyCode:that.data.verifyCode,
               'content-type': 'application/x-www-form-urlencoded'
              },
              success (res) {
               var data = res.data;
              //  console.log(data)
               if(data.state==1){
                  that.setData({
                    workIsCollect:!data.data
                  })
                  wx.showToast({
                    title: '取消成功',
                    icon: 'success',
                    duration: 2000
                  })
               }
             },
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
   
  },
  //  习题格式修改
  options_key:function (data) {
    var that= this;
    var questions = data.questions,
        question_leng = questions.length;
    // console.log(questions.length)
    // console.log(data)
    for(var i=0;i<question_leng;i++){
      questions[i].final_answer='';
      if(questions[i].type=='简答'){
        questions[i].subject_type=0;
        questions[i].on_option=1; //控制下一题按钮
      }else{
        questions[i].subject_type=1;
        if(questions[i].type=='单选'){
          questions[i].on_option=0; //控制下一题按钮
        }else{
          questions[i].on_option=1; //控制下一题按钮
        }
        
      }
    }
    wx.hideLoading()
    that.setData({
      question_leng:question_leng,
      work_data:data
    })
    
  },
   //获取套题详情
  show_wrok:function (data) {
    wx.showLoading({
      title: '获取中',
    })
    var that = this;
    return new Promise(function(resolve, reject) {
      wx.request({
        url: 'https://graceful.top/exercise/work_question/queryWorkContent2',
        data:data,
        method:'POST',
        header:{
         verifyCode:that.data.verifyCode,
         'content-type': 'application/x-www-form-urlencoded'
        },
        success (res) {
         var data = res.data;
        //  console.log(data)
         if(data.state==1){
          return resolve(data.data);
         }
        },
        fail(res){
          wx.hideLoading();
          return reject('falied param');
        }
      })
    })
   
  },
  // 计时器
  setInterval: function () {
    const that = this
    var second = that.data.second
    var minute = that.data.minute
    var hours = that.data.hours       
    setInterval(function () {  // 设置定时器
        second++
        if (second >= 60) {
            second = 0  //  大于等于60秒归零
            minute++
            if (minute >= 60) {
                minute = 0  //  大于等于60分归零
                hours++
                if (hours < 10) {
                    // 少于10补零
                    that.setData({
                        hours: '0' + hours
                    })
                } else {
                    that.setData({
                        hours: hours
                    })
                }
            }
            if (minute < 10) {
                // 少于10补零
                that.setData({
                    minute: '0' + minute
                })
            } else {
                that.setData({
                    minute: minute
                })
            }
        }
        if (second < 10) {
            // 少于10补零
            that.setData({
                second: '0' + second
            })
        } else {
            that.setData({
                second: second
            })
        }
    }, 1000)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})