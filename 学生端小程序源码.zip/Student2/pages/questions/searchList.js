// pages/questions/searchList.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */ 
  data: {
    verifyCode:'',
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    question_key:'true',
    sort_key:2,
    work_data:'',
  },
   //页面返回上一层
   page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    // console.log(answer)
    //自定义头部方法
    this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
         verifyCode = wx.getStorageSync('verifyCode');
      that.setData({
        windowHeight:windowHeight-that.data.navH,
        verifyCode:verifyCode
      })
      const eventChannel = this.getOpenerEventChannel()
      // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
      eventChannel.on('acceptDataFromOpenerPage', function(data) {
        console.log(data)
        that.show_search(data.data,1,10);
      })
  },
  //获取搜索列表
  show_search:function (key,startPage,pageSize) {
    var that = this;
    wx.request({
      url: 'https://graceful.top/exercise/work/queryVague',
      data:{
        key:key,
        startPage:startPage,
       pageSize:pageSize
      },
      method:'POST',
      header:{
       verifyCode:that.data.verifyCode,
       'content-type': 'application/x-www-form-urlencoded'
      },
      success (res) {
       wx.hideLoading()
       var data = res.data;
       console.log(data)
       if(data.data.works.length!=0){
        for(var i=0;i<data.data.works.length;i++){
          var key = Math.floor(Math.random()*(10 - 1) + 1);
          data.data.works[i].work_img='https://graceful.top/exercise/static/slices/'+key+'.png'
        }
        that.setData({
          work_data:data.data.works,
          question_key:false
        })
       }
     },
     fail(res){
       wx.hideLoading()
     }
    })  
  },
  //点击套题
  on_work:function (e) {
    console.log(e)
    var workId = e.currentTarget.dataset.workid,
         teacherId = e.currentTarget.dataset.teacherid;
      // console.log(workId)
    wx.navigateTo({
      url: '/pages/questions/questionList?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', {workId:workId,
          teacherId:teacherId})
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})