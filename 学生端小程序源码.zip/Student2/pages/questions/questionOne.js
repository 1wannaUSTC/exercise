// pages/questions/questionOne.js
const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    verifyCode:'',
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    questionList:'',
    subject_type:1,    //题型 1为选择  0 为简答
    correct_key:0,    //是否正确  1正确  2错误
    answer:'',    //正确答案  多选与简答需要用
    get_score:'',  //最终得分
    textareaAValue:'',
    Collection_state:'',   //收藏状态
    comment_leng:-1,
  }, 
  //页面返回上一层
  page_back:function (params) {
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var i= 1;
     
    //自定义头部方法
    this.setData({
      navH: app.globalData.navHeight
     }); 
     var windowHeight = wx.getSystemInfoSync().windowHeight,
         verifyCode = wx.getStorageSync('verifyCode');
     that.setData({
      verifyCode:verifyCode,
      windowHeight:windowHeight-that.data.navH
     })
    // console.log(windowHeight)
    // console.log(options.query)
    const eventChannel = this.getOpenerEventChannel()
    // 监听acceptDataFromOpenerPage事件，获取上一页面通过eventChannel传送到当前页面的数据
    eventChannel.on('acceptDataFromOpenerPage', function(data) {
          console.log(data)
          var questionList = data.data;
          console.log(questionList)
          if(questionList.type=='简答'){
            that.setData({
              questionList:questionList,
              subject_type:0
            })
          }else{
            var option = questionList.option.split(questionList.uuidShort)
            var str = [];
            for(var i=0;i<option.length;i++){   //分隔字符choose：A，option：A、答案
              var a = {};
              a.option = option[i];
              a.correct_key = 0;
              a.choose = option[i].slice(0,1);
              a.isOk=false;
              str.push(a);
            }
            questionList.options=str;
            // console.log(option)
            that.setData({
              questionList:questionList,
            })
            
          }
          that.Collection_state(questionList);
    })
  },
  // 选择问题答案点击
  on_option:function (res) {
    // console.log(res)
    var that = this,
    questionList = that.data.questionList,
    key = res.target.dataset.key;
    if(questionList.type=='单选'){   //单选  多选判断
      for(let i=0;i<questionList.options.length;i++){   //单选唯一控制
        // console.log("key:"+key,"i:"+i);
        if(key!=i){
          questionList.options[i].isOk = false;
        }
      }
      questionList.options[key].isOk = !questionList.options[key].isOk;   //点击取反
      that.setData({
        questionList:questionList
      })
    }else if(questionList.type=='多选'){
      questionList.options[key].isOk = !questionList.options[key].isOk;   //点击取反
      that.setData({
        questionList:questionList
      })
    }
  },
  //简答问题事件
  textareaAInput(e) {
    this.setData({
      textareaAValue: e.detail.value
    })
  },
   //答案提交
  on_Submission:function () {
    var _seft = this,
        questionList = _seft.data.questionList,
        isValue=false,
        answer = '';
        //单选、多选答案value值检索是否为空
        if(questionList.type!='简答'){
          for(let i=0;i<questionList.options.length;i++){
            if(questionList.options[i].isOk==true){
              answer+=questionList.options[i].choose+'、';
              isValue=true;
            }
          }
          answer = answer.substr(0, answer.length-1)
        }else{    //简答答案value是否为空
          var textareaAValue = _seft.data.textareaAValue;
          if(textareaAValue!=''){
            answer = textareaAValue;
            isValue =true;
          }
        }
        // 是否提交习题争取判断请求
        if(isValue){
          wx.showLoading({
            title: '审批中',
          })
          // console.log(answer)
          var studentInfo = wx.getStorageSync('studentInfo'),
              studentId = studentInfo.studentInfo,
              questionId  = questionList.questionId;
          // 发送请求
          wx.request({
            url: 'https://graceful.top/exercise/question/readOne',
            data:{
              studentId:studentId,
              questionId:questionId,
              answer:answer
            },
            method:'POST',
            header:{
             verifyCode:_seft.data.verifyCode,
             'content-type': 'application/x-www-form-urlencoded'
            },
            success (res) {
              var data = res.data;
              // console.log(data)
              if(data.state==1){
                if(questionList.type=='单选'){
                  if(data.data.correct){   //判断正确性
                    wx.showToast({
                      title: '答案正确',
                      icon: 'none',
                      duration: 2000
                    })
                    for(let i=0;i<questionList.options.length;i++){
                      if(questionList.options[i].isOk==true){   //显示错误答案
                        questionList.options[i].correct_key=1;    //显示正确小勾
                        break;
                      }
                    }
                    _seft.setData({
                      questionList:questionList
                    })
                  }else{
                    wx.showToast({
                      title: '答案错误',
                      icon: 'none',
                      duration: 2000
                    })
                    var correct_value = data.data.answer;
                    for(let i=0;i<questionList.options.length;i++){   //显示正确答案
                      console.log("choose:"+questionList.options[i].choose)
                      console.log("correct_value:"+correct_value)
                      if(questionList.options[i].choose==correct_value){
                        questionList.options[i].correct_key=1;    //显示正确小勾
                        questionList.options[i].isOk=3;
                      }
                      if(questionList.options[i].isOk==true){   //显示错误答案
                        questionList.options[i].correct_key=2;    //显示错误小勾
                        questionList.options[i].isOk=2;
                      }
                    }
                    _seft.setData({
                      questionList:questionList
                    })   
                  }
                }else if(questionList.type=='多选'){
                  if(data.data.correct){    //正确
                    wx.showToast({
                      title: '答案正确',
                      icon: 'none',
                      duration: 2000
                    })
                    for(let i=0;i<questionList.options.length;i++){
                      if(questionList.options[i].isOk==true){   //显示错误答案
                        questionList.options[i].correct_key=1;    //显示正确小勾
                      }
                    }
                    _seft.setData({
                      questionList:questionList
                    })
                  }else{  //错误
                    wx.showToast({
                      title: '答案错误',
                      icon: 'none',
                      duration: 2000
                    })
                    var correct_value = data.data.answer,
                        get_score = data.data.get+'分';
                    for(let i=0;i<questionList.options.length;i++){   //显示正确答案
                      if(questionList.options[i].isOk==true){   //显示错误答案
                        questionList.options[i].correct_key=2;    //显示错误小勾
                        questionList.options[i].isOk=2;
                      }
                    }
                    _seft.setData({
                      questionList:questionList,
                      answer:correct_value,
                      get_score:get_score
                    })
                  }
                }else if(questionList.type=='简答'){
                  if(data.data.correct){
                    var get_score = data.data.get.toFixed(2)+'分',
                    correct_value = data.data.answer;
                    wx.showToast({
                      title: '答案正确',
                      icon: 'none',
                      duration: 2000
                    })
                    _seft.setData({
                      answer:correct_value,
                      get_score:get_score
                    })
                  }else{
                    wx.showToast({
                      title: '答案错误',
                      icon: 'none',
                      duration: 2000
                    })
                    var correct_value = data.data.answer,
                     get_score = data.data.get.toFixed(2)+'分';
                    _seft.setData({
                      answer:correct_value,
                      get_score:get_score
                    })
                  }
                }
              }else{
                wx.showToast({
                  title: '网络错误',
                  icon: 'none',
                  duration: 2000
                })
              }
            },
          })
          // 请求评论
          wx.request({
            url: 'https://graceful.top/exercise/QuestionComment/countComment',
            data:{
              questionId:questionId,
            },
            method:'POST',
            header:{
             verifyCode:_seft.data.verifyCode,
             'content-type': 'application/x-www-form-urlencoded'
            },
            success (res) {
              wx.hideLoading();
              var data = res.data;
              // console.log("问题评论：",data)
              if(data.state==1){
                _seft.setData({
                  comment_leng:data.data
                })
              }else{
                wx.showToast({
                  title: '网络错误',
                  icon: 'none',
                  duration: 2000
                })
              }
            },
          })
        }else{
          wx.showToast({
            title: '答案为空',
            icon: 'none',
            duration: 2000
          })
        }
  },
  //判断收藏状态
  Collection_state:function (data) {
    var that =this;
      wx.request({
        url: 'https://graceful.top/exercise/question/isCollect',
        data:{
          questionId:data.questionId
        },
        method:'POST',
        header:{
         verifyCode:that.data.verifyCode,
         'content-type': 'application/x-www-form-urlencoded'
        },
        success (res) {
         var data = res.data;
        //  console.log(data)
         if(data.state==1){
            that.setData({
              Collection_state:data.data
            })
         }
       },
      })
   
  },
  //收藏按钮
  on_Collection:function (e) {
    var that = this;
    // console.log(e)
    var that =this,
        questionId = that.data.questionList.questionId,
        Collection_state=that.data.Collection_state;
    if(!Collection_state){    //收藏接口
      wx.showModal({
        title: '提示',
        content: '收藏习题',
        success (res) {
          if (res.confirm) {
            wx.request({
              url: 'https://graceful.top/exercise/question/collect',
              data:{
                questionId:questionId,
                cancelOrCollect:!Collection_state
              },
              method:'POST',
              header:{
               verifyCode:that.data.verifyCode,
               'content-type': 'application/x-www-form-urlencoded'
              },
              success (res) {
               var data = res.data;
              //  console.log(data)
               if(data.state==1){
                  that.setData({
                    Collection_state:data.data
                  })
                  wx.showToast({
                    title: '收藏成功',
                    icon: 'success',
                    duration: 2000
                  })
               }
             },
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '取消收藏',
        success (res) {
          if (res.confirm) {
            wx.request({
              url: 'https://graceful.top/exercise/question/collect',
              data:{
                questionId:questionId,
                cancelOrCollect:!Collection_state
              },
              method:'POST',
              header:{
               verifyCode:that.data.verifyCode,
               'content-type': 'application/x-www-form-urlencoded'
              },
              success (res) {
               var data = res.data;
              //  console.log(data)
               if(data.state==1){
                  that.setData({
                    Collection_state:!data.data
                  })
                  wx.showToast({
                    title: '取消成功',
                    icon: 'success',
                    duration: 2000
                  })
               }
             },
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  },
  //分享按钮
  on_share(){
    
  },
  //查看更多评论
  on_comment(e){
    var that = this;
    wx.navigateTo({
      url: '/pages/index/question_comment/question_comment?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
        
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', { 
          questionId:that.data.questionList.questionId

        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady:function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})