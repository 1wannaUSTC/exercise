// pages/questions/questions.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: { 
    navH:'',   //头部高度
    windowHeight:'',    //可使用高度
    text_type:"", //题型难度控制 
    sezrch_value:'',
    sort_key:1, //排列切换key
    difficulty: ['不限','简单', '一般', '困难'],
    difficulty_key:null,
    type_key:null,
    score:['不限','50','100','150','200'],
    score_key:null,
    subject:'',
    subjectList:'',   //json格式
    subject_key:null,
    work_data:[],   //作业列表
    totalPage:0,   //作业总页数
    pageStart:1,  //请求页数
    verifyCode:'',
    scroll_top: 0, // 滚动到位置。
    start_scroll: 0, // 滚动前的位置。
    touch_down: 0 // 触摸时候的 Y 的位置
  },
  // start: 触摸开始
  start_fn (e) {
        let self = this;
       let touch_down = e.touches[0].clientY;
       this.data.touch_down = touch_down;
        // 获取 scroll-wrap 的高度和当前的 scrollTop 位置
     wx.createSelectorQuery().select('#scroll-wrap').fields({
           scrollOffset: true,
           size: true
       }, function (rect) {
           self.data.start_scroll = rect.scrollTop;
           self.data.height = rect.height;
       }).exec();
  } ,
  // start： 触摸结束
  end_fn (e) {
       let current_y = e.changedTouches[0].clientY;
       let self = this;
       let { start_scroll, touch_down} = this.data;
      
      if (current_y > touch_down && current_y - touch_down > 80 && start_scroll == 0) {
         // 下拉刷新 的请求和逻辑处理等
        // console.log("下拉")
        wx.showLoading({
          title: '加载中',
        })
        var verifyCode = this.data.verifyCode,
        that = this,
        subjectId='',result='',difficulty='';
        wx.request({
          url: 'https://graceful.top/exercise/work/query',
          data:{
           subjectId:subjectId,
           result:result,
           difficulty:difficulty,
           startPage:1,
           pageSize:6
          },
          header:{
           verifyCode:verifyCode,
           'content-type': 'application/json'
          },
          success (res) {
           wx.hideLoading()
           var data = res.data;
           console.log(data)
           if(data.state==1){
             console.log("res:"+data.data.works[0].workId);
             console.log("this:"+that.data.work_data[0].workId)
             if(data.data.works[0].workId==that.data.work_data[0].workId){
              wx.showToast({
                title: '已是最新套题',
                icon: 'none',
                duration: 2000
              })
             }else{
              for(var i=0;i<data.data.works.length;i++){
                  var key = Math.floor(Math.random()*(10 - 1) + 1);
                  data.data.works[i].work_img='https://graceful.top/exercise/static/slices/'+key+'.png'
                }
                wx.setStorageSync('work_data', data.data.works);
                wx.setStorageSync('totalPage', ata.data.pageInfo.totalPage);
                that.setData({
                  totalPage:data.data.pageInfo.totalPage,
                  pageStart:data.data.pageInfo.pageStart,
                  work_data:data.data.works
                })
             }
           }else{
             wx.showToast({
               title: '网络错误',
               icon: 'none',
               duration: 2000
             })
           }
         },
         fail(res){
           wx.hideLoading()
         }
        }) 
      }
  },
  // end: 触摸结束
  // end: 触摸开始
  //懒加载
  tolower(){
      var pageStart = this.data.pageStart+1,
          totalPage = this.data.totalPage,
          work_data = wx.getStorageSync('work_data');
            if(work_data!=''&&totalPage!=0){    //为了不重复刷新图片，村缓存
              wx.showLoading({
                title: '加载中',
              })
              if(totalPage>=pageStart){
                if(this.data.difficulty_key!=null){
                  this.screen_wrok(1,6,this.data.difficulty[this.data.difficulty_key])
                }else if(this.data.subject_key!=null){
                  this.screen_wrok(1,6,this.data.subjectList[this.data.subject_key].subjectId)
                }else if(this.data.score_key!=null){
                  this.screen_wrok(1,6,this.data.score[this.data.score_key])
                }else{
                  this.data_wrok(pageStart,6)
                }
               
              }else{
                wx.hideLoading()
                wx.showToast({
                  title: '已加载全部',
                  icon: 'none',
                  duration: 2000
                })
              }
            }
         
     
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中',
    })
    var that=this;
    var verifyCode = wx.getStorageSync('verifyCode');
    that.setData({
      verifyCode:verifyCode
    })
    //自定义头部方法
     var windowHeight = wx.getSystemInfoSync().windowHeight;
      that.setData({
        navH: app.globalData.navHeight,
        windowHeight:windowHeight-app.globalData.navHeight
      })
    var work_data = wx.getStorageSync('work_data'),
        totalPage = that.data.totalPage;
    if(work_data==''&&totalPage==0){    //为了不重复刷新图片，村缓存
      that.data_wrok(that.data.pageStart,6);
    }else{
      var totalPage = wx.getStorageSync('totalPage')
      wx.hideLoading()
      that.setData({
        totalPage:totalPage,
        work_data:work_data
      })
    }
    that.subject_value();
    
  },
  //点击套题
  on_work:function (e) {
    console.log(e)
    var workId = e.currentTarget.dataset.workid,
         teacherId = e.currentTarget.dataset.teacherid;
    wx.navigateTo({
      url: '/pages/questions/questionList?id=1',
      events: {
        // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
        acceptDataFromOpenedPage: function(data) {
          // console.log(data)
        },
        someEvent: function(data) {
          // console.log(data)
        }
      },
      success: function(res) {
        // 通过eventChannel向被打开页面传送数据
        res.eventChannel.emit('acceptDataFromOpenerPage', {
          workId:workId,
          teacherId:teacherId
        })
      }
    })
  },
  //获取套题列表数据
  data_wrok:function (startPage,pageSize) {
    var verifyCode = this.data.verifyCode,
        that = this;
     wx.request({
       url: 'https://graceful.top/exercise/work/query',
       data:{
        startPage:startPage,
        pageSize:pageSize
       },
       header:{
        verifyCode:verifyCode,
        'content-type': 'application/json'
       },
       success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1){
          for(var i=0;i<data.data.works.length;i++){
            var key = Math.floor(Math.random()*(10 - 1) + 1);
            data.data.works[i].work_img='https://graceful.top/exercise/static/slices/'+key+'.png'
          }
          var con_data = that.data.work_data;
              // console.log(con_data)
              con_data = con_data.concat(data.data.works);
          if(startPage==1){
            wx.setStorageSync('work_data', data.data.works);
            wx.setStorageSync('totalPage', data.data.pageInfo.totalPage)
            that.setData({
              totalPage:data.data.pageInfo.totalPage,
              pageStart:data.data.pageInfo.pageStart,
              work_data:data.data.works
            })
          }else{
            // console.log(con_data)
            that.setData({
              pageStart:data.data.pageInfo.pageStart,
              work_data:con_data
            })
          }
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail(res){
        wx.hideLoading()
      }
     })
  },
  //筛选套题
  screen_wrok:function (startPage,pageSize,value) {
    var verifyCode = this.data.verifyCode,
        that = this,
        subjectId='',result='',difficulty='';
        console.log(value)
    if(value!='不限'&&value!='0'){
      for(var i=0;i<4;i++){
        if(value==that.data.score[i]){
          result = value;
          break;
        }else if(value==that.data.difficulty[i]){
          // console.log(that.data.difficulty[i])
          difficulty=value;
          break;
        }
      }
      if(difficulty==''&&result==''&&value!=undefined){
        subjectId=value;
      }
    }
    console.log(difficulty)
     wx.request({
       url: 'https://graceful.top/exercise/work/query',
       data:{
        subjectId:subjectId,
        result:result,
        difficulty:difficulty,
        startPage:startPage,
        pageSize:pageSize
       },
       header:{
        verifyCode:verifyCode,
        'content-type': 'application/json'
       },
       success (res) {
        wx.hideLoading()
        var data = res.data;
        console.log(data)
        if(data.state==1){
          for(var i=0;i<data.data.works.length;i++){
            var key = Math.floor(Math.random()*(10 - 1) + 1);
            data.data.works[i].work_img='https://graceful.top/exercise/static/slices/'+key+'.png'
          }
          if(startPage==1){
            var con_data = [];
              // console.log(con_data)
              con_data = con_data.concat(data.data.works);
              that.setData({
                totalPage:data.data.pageInfo.totalPage,
                pageStart:data.data.pageInfo.pageStart,
                work_data:con_data
              })
          }else{
            var con_data = that.data.work_data;
              // console.log(con_data)
              con_data = con_data.concat(data.data.works);
              that.setData({
                pageStart:data.data.pageInfo.pageStart,
                work_data:con_data
              })
          }
          
          
          
        }else{
          wx.showToast({
            title: '网络错误',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail(res){
        wx.hideLoading()
      }
     })
  },
  //获取学科接口
  subject_value:function () {
    var that = this,
    data =wx.getStorageSync('subjectList');
     //获取所有学科
          var a=[];
          data.unshift({
            subjectId:0,
            subjectName:"不限"
          })
          for(var i=0;i<data.length;i++){
            var subjectName = data[i].subjectName;
            a.push(subjectName)
          }
          that.setData({
            subject:a,
            subjectList:data
          })
  },
  //搜索按钮事件
  on_search:function (e) {
    console.log(e)
    var value = e.detail.value,
        that = this;
    if(value==''){
      wx.showToast({
        title: '请输入内容！',
        icon: 'none',
        duration: 1000
      })
    }else{
      wx.navigateTo({
        url: '/pages/questions/searchList?id=1',
        events: {
          // 为指定事件添加一个监听器，获取被打开页面传送到当前页面的数据
          acceptDataFromOpenedPage: function(data) {
            // console.log(data)
          },
          someEvent: function(data) {
            // console.log(data)
          }
        },
        success: function(res) {
          // 通过eventChannel向被打开页面传送数据
          res.eventChannel.emit('acceptDataFromOpenerPage', { data:value })
          that.setData({
            sezrch_value:''
          })
        }
      })
    }
  },
  //排列图标点击事件
  click_Sort:function(e){
    var key = e.currentTarget.dataset.index
    this.setData({
      sort_key:~key   //取反运算
    })
  },
  //难度选择
  difficulty_Change(e) {
    // console.log(e);
    wx.showLoading({
      title: '加载中',
    })
    if(e.detail.value=='0'){
      this.setData({
        difficulty_key:null
      })
      this.data_wrok(1,6)
    }else{
      this.setData({
        difficulty_key:e.detail.value
      })
      this.screen_wrok(1,6,this.data.difficulty[e.detail.value])
    }
    
    
  },
  //分值选择
  score_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    // console.log(e);
    if(e.detail.value=='0'){
      this.setData({
        score_key:null
      })
      this.data_wrok(1,6)
    }else{
      this.setData({
        score_key: e.detail.value
      })
      this.screen_wrok(1,6,this.data.score[e.detail.value])
    }
  },
  //学科选择
  subject_Change(e) {
    wx.showLoading({
      title: '加载中',
    })
    // console.log(e);
    if(e.detail.value=='0'){
      this.setData({
        subject_key:null
      })
      this.data_wrok(1,6)
    } else{
      this.setData({
        subject_key: e.detail.value
      })
      this.screen_wrok(1,6,this.data.subjectList[e.detail.value].subjectId)
    }
   
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})