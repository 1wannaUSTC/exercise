//app.js
App({
  onLaunch: function () {
    var that =this;
    // 展示本地存储能力
    // var logs = wx.getStorageSync('logs') || []
    // logs.unshift(Date.now())
    // wx.setStorageSync('logs', logs)
    
    // 获取顶部栏信息
   wx.getSystemInfo({
    success: res => {
      //导航高度
      this.globalData.navHeight = res.statusBarHeight + 46;
    }, fail(err) {
      console.log(err);
    }
    })
  },
  //授权函数
  userLogin:function (res) {
    var that = this;
    let promise = new Promise((resolve, reject)=>{
     // 获取用户信息 
     wx.getSetting({
      success: function(res) {
          if (res.authSetting['scope.userInfo']) {
              wx.getUserInfo({
                  success: function(res) {
                    that.globalData.userInfo=res.userInfo;
                      wx.login({
                          success: res => {
                              console.log(res)
                              // 获取到用户的 code 之后：res.code
                              console.log("用户的code:" + res.code);
                            if (res.code) {
                                //发起网络请求
                                wx.request({
                                  url: 'https://graceful.top/exercise/student/login',
                                  data: {
                                    code: res.code,
                                    loginType:'wx',
                                    avatar:that.globalData.userInfo.avatarUrl,
                                    nickName:that.globalData.userInfo.nickName,
                                    gender:that.globalData.userInfo.gender
                                  },
                                  header:{'content-type':'application/json'},
                                  success:function (res) {
                                    wx.hideLoading()
                                      console.log(res)
                                      if(res.statusCode==200&&res.data.state==1){//改变登录状态
                                        that.globalData.islogin=true;
                                        wx.setStorageSync('islogin', that.globalData.islogin);
                                        wx.setStorageSync('studentInfo', res.data.data.studentInfo)
                                        // wx.setStorageSync('verifyCode', 'test-student18')
                                        wx.setStorageSync('verifyCode', res.data.data.verifyCode)
                                        resolve(that.globalData.islogin);
                                      }else{
                                        wx.showToast({
                                          title: '网络错误',
                                          icon: 'none',
                                          duration: 2000
                                        })
                                      }
                                      // console.log(that.globalData.islogin)
                                  },
                                  fail:function(res) {
                                    wx.hideLoading()
                                    console.log(res);
                                    reject(that.globalData.islogin)
                                    wx.showToast({
                                      title: '服务器异常',
                                      icon: 'none',
                                      duration: 2000
                                    })
                                    
                                  }
                                })
                              }else {
                                console.log('登录失败！' + res.errMsg);
                                wx.showToast({
                                  title: '登录失败',
                                  icon: 'none',
                                  duration: 2000
                                })
                              }
                          }
                      });
                  }
              });
          } else {
              // 用户没有授权
             console.log("没有授权")
          }
      }
     });
    })
    return promise;
  },
  globalData: {
    islogin: false, //授权状态
    userInfo:'',
    navHeight: 0
  }
})