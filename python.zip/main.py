#!/usr/bin/env python
# -*- coding:utf-8 -*-
# Author: Hogan


from fastapi import FastAPI, requests
from pydantic import BaseModel

app = FastAPI()
from text2vec import Similarity


class GetData(BaseModel):
    answer: str
    reply: str


@app.post("/api/ai")
async def root(getData: GetData):
    sim = Similarity()
    reply=getData.reply
    answer = getData.answer
    sc_tmp = sim.get_score(answer, reply)
    return {"score": sc_tmp}
